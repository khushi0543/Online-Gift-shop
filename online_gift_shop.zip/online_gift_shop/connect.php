<?php 
$con=mysqli_connect("localhost","root","")or die("Database Not Found");
mysqli_select_db($con,"onlinegiftshop") or die("Database Not Found");
?>
