-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2024 at 06:46 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinegiftshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `brandname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `brandname`) VALUES
(1, 'westisite'),
(6, 'Zudio'),
(7, 'Zudio'),
(9, 'cake -chakers'),
(10, 'sweet cakes'),
(11, 'The cakefast'),
(12, 'drewbarrymore'),
(13, 'zara'),
(14, 'Valspar'),
(15, 'philippines'),
(16, 'Murasaki'),
(17, ' Brass'),
(18, 'Tomy.'),
(19, 'The Good Road'),
(20, 'Luxury Handbag'),
(21, 'Beardo'),
(22, 'Aigner'),
(23, ' bakingo');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`) VALUES
(1, 'Laptop'),
(3, 'pensil');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryname`) VALUES
(1, 'Flower'),
(5, 'Home decor'),
(6, 'Cake'),
(7, 'Diwali'),
(8, 'Fashion'),
(9, 'Person'),
(10, 'Trending');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `id` int(11) NOT NULL,
  `colorname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`id`, `colorname`) VALUES
(7, 'Red'),
(8, 'Green'),
(9, 'Blue'),
(10, 'Black'),
(11, 'White'),
(12, 'Pink'),
(13, 'Radium'),
(14, 'no');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `regularprice` float NOT NULL,
  `saleprice` float NOT NULL,
  `description` varchar(250) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `name`, `brand_id`, `category_id`, `subcategory_id`, `color_id`, `size_id`, `qty`, `regularprice`, `saleprice`, `description`, `image`) VALUES
(1, 'Cake', 9, 6, 18, 8, 1, 3, 3000, 2980, 'The cake stand, cutlery accessories used in the image are only for representation purposes. They are not delivered with the cake.', 'bday.jpeg'),
(2, 'Rose Paradise Chocolate Cake Half Kg', 10, 6, 13, 9, 1, 34, 2500, 2400, 'Product Details:\r\n\r\nCake Flavour- Chocolate\r\nType of Cake- Cream\r\nShape- Round\r\nWeight: 500 gm\r\nNet Quantity: 1 Cake\r\nDiameter: 7.5 inch\r\nCountry Of Origin: India\r\nServes: 4-6 People', 'bs.jpeg'),
(3, 'Butterscotch Cake Half kg', 12, 0, 13, 11, 1, 6, 549, 500, 'Product Details:\r\n\r\nCake Flavour- Butterscotch\r\nType of Cake - Cream\r\nShape- Round\r\nWeight: 500 gm\r\nNet Quantity: 1 Cake\r\nDiameter: 7.5 inch\r\nCountry Of Origin: India\r\nServes: 4-6 People', 'bs3.jpeg'),
(4, ' Anniversary Fondant 2 Tier Cake', 10, 6, 18, 8, 1, 23, 1500, 1400, 'product Details:\r\n\r\n*Cake Flavour- Chocolate\r\n\r\nType of Cake- Fondant\r\nWeight- 3 Kg\r\nShape- Round\r\nServes- 30-36 People\r\nSize- 12 Inches in Diameter\r\nNet Quantity- 1\r\nCountry of Origin- India', 'ann3.jpeg'),
(5, 'Happy Anniversary Heart Shaped Cake', 11, 6, 18, 7, 1, 2, 2000, 1900, 'Product Details:\r\n\r\nCake Flavour- Chocolate\r\nType Of Cake- Cream\r\nWeight- Half Kg\r\nCake Shape- Heart Shaped\r\nServes- 4-6 People\r\nSize- 6 Inches in Diameter\r\nNet Quantity- 1\r\nCountry of Origin- India', 'ann2.jpeg'),
(6, 'Cream Drop Chocolate Cake Half Kg', 9, 6, 18, 7, 1, 3, 700, 690, 'Product Details:\r\n\r\nCake Flavour- Chocolate\r\nType of Cake- Cream\r\nShape- Round\r\nWeight: 500 gm\r\nNet Quantity: 1 Cake\r\nDiameter: 7.5 inch\r\nCountry Of Origin: India\r\nServes: 4-6 People', 'ann.jpeg'),
(7, 'Personalised Grace Pink Rose Bouquet', 15, 1, 9, 12, 2, 2, 1225, 1200, 'Elevate your gifting with our rose bouquet, wrapped in a personalised wrapping paper adorned with the recipients name. A gesture of thoughtfulness and care, this gift encapsulates the beauty of dark pink roses, a symbol of appreciation and admiration', 'annfl.jpeg'),
(8, 'Love For Pastel Carnations Flower Bouquet', 12, 1, 9, 7, 1, 2, 799, 750, 'Handpicked baby pink carnations to let the special someone know how much you miss them. Show your emotions with carnations, beautifully arranged in bouquet style and sprinkled with White Gypsophila Gypsy Fillers. These beautiful flowers will make the', 'annfl2.jpeg'),
(9, 'Magical Dust Carnations', 12, 1, 18, 9, 2, 2, 899, 865, 'Create a magical moment for your loved one This enchanting gift features a bouquet of delicate baby pink carnations, radiating elegance and charm. Enhanced with white gypsophila fillers, the arrangement is a sight to behold', 'annfl3.jpeg'),
(10, 'LED Lamp Speaker', 15, 5, 27, 11, 2, 23, 699, 678, 'One Personalised Happy Birthday Bluetooth Multi Colour LED Speaker\r\nTouch Lamp Portable Speaker\r\nWarm-White LED Table Lamp\r\nBuilt-in Smart Touchable Induction', 'led.jpeg'),
(11, 'Name-In-Lights Harmony Lamp', 15, 5, 27, 13, 2, 3, 599, 477, 'Alphabet 3d LED lamp: 1\r\nColour: Warm white\r\n6 x 4 HXL inches\r\nCan be personalised with 1 alphabet, occasion and name.', 'p2.jpg'),
(12, 'Personalised Mug For Her', 16, 10, 28, 11, 3, 3, 377, 280, 'One Personalised Mug\r\nMaterial-Ceramic\r\nDimensions-Height: 4 inches Diameter: 3 inches\r\nColour-White', 'mug2.jpeg'),
(13, 'Dreamy Cushion', 21, 10, 26, 11, 2, 2, 5999, 4500, 'Transform any space into a gallery with this stunning abstract art cushion. Featuring vibrant, intricate designs, this cushion adds a splash of creativity and elegance to any room. Ideal for art enthusiasts, new homeowners, or anyone who loves a touc', 'cushion.jpeg'),
(14, 'Personalised Embrace Cushion', 21, 10, 26, 9, 2, 2, 699, 599, 'Give a gift that s both personal and cosy with this custom pipping cushion. Personalised with a cherished image of your choice', 'cushion3.jpeg'),
(15, 'Personalised Embrace Cushion', 21, 0, 26, 9, 2, 2, 699, 699, 'Give a gift that s both personal and cosy with this custom pipping cushion. Personalised with a cherished image of your choice', 'cushion2.jpeg'),
(16, 'Carlton London Men Azure Luxe Gift', 6, 8, 16, 14, 2, 2, 600, 600, 'Unveil a gift that speaks of refined elegance and thoughtfulness. Carlton London Men Azure captivates with its blend of smooth fruits, zesty ginger, and lemon, harmonised by aromatic amber and white musk. This sophisticated scent is perfect for the i', 'perfume2.jpeg'),
(17, 'Diamond Studded Watches', 21, 8, 17, 12, 2, 4, 466, 420, 'This is a stylish minimalist design ladies watch.Classic rose gold dial design fully showcasing the beauty and charm of women, sufficient match any of your outfits.', 'watch2.jpeg'),
(18, 'Toy', 23, 5, 24, 12, 2, 1, 999, 950, 'Meet Smokey Bear, the cuddly teddy bear ready to warm hearts. With its soft fur and adorable demeanour, its the perfect gift for anyone needing a hugwhether a child', 'toy.jpeg'),
(19, 'Shoulder Bag', 13, 8, 15, 9, 2, 3, 3000, 2900, 'Product details\r\nFabric typeNylon\r\nOriginè¿›å£\r\nCountry of OriginChina', 'p4.jpg'),
(20, 'Diwali Gift', 11, 0, 14, 14, 2, 3, 300, 289, 'send your loved ones on a delightful diwali journey with this mesmerising gift box containing handpicked and roasted dry fruits while adding a touch of resplendent brass diya to set the ambiance', 'diwali3.jpg'),
(21, 'Avatar ', 18, 9, 25, 13, 2, 2, 799, 650, 'Gift for Friends, Sister, Brother, BFF, Girlfriend, Boyfriend Character Caricature Photo Frame Unique Design Customized Gift for Friends & Family', 'cc2.jpeg'),
(22, ' Flower Bouquet', 14, 1, 20, 13, 2, 2, 342, 320, 'Elegant Arrangement: Features 6 vibrant red roses, creating a stunning and passionate bouquet.', 'fl2.jpeg'),
(23, 'Baby Shower  cake', 10, 6, 12, 9, 3, 3, 700, 650, 'Store cream cakes in a refrigerator. Fondant cakes should be stored in an air conditioned environment.', 'bs2.jpeg'),
(24, 'Bamboo Plant', 17, 5, 22, 8, 1, 4, 399, 350, 'Plant Name-Bamboo Plant: 1 Height Up To 8-10 Inches\r\nPlant Placement-Indoors\r\nTransparent Square Glass Vase: 1 3x3x3 Inch', 'plant.jpeg'),
(25, 'cake', 9, 6, 12, 8, 2, 2, 450, 340, 'goefr', 'bs3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `id` int(11) NOT NULL,
  `sizename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`id`, `sizename`) VALUES
(1, 'small'),
(2, 'mediam'),
(3, 'large');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `subcategoryname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategoryname`) VALUES
(1, 0, 'Subcategory 1'),
(6, 4, 'TOYS'),
(9, 6, 'aniversary'),
(12, 6, 'baby shower'),
(13, 6, 'birthday'),
(14, 7, 'diwali'),
(15, 8, 'bag'),
(16, 8, 'perfume'),
(17, 8, 'watch'),
(18, 1, 'aniversary'),
(19, 1, 'wedding'),
(20, 1, 'bouquet'),
(21, 5, 'painting'),
(22, 5, 'plant'),
(23, 5, 'shpiece'),
(24, 5, 'toy'),
(25, 9, 'custom caricature'),
(26, 10, 'cushion'),
(27, 10, 'light'),
(28, 10, 'mug'),
(0, 1, 'toy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
