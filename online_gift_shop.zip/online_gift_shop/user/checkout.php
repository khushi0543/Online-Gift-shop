<?php
session_start();
include "db.php"; // Database connection logic

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    echo "Your cart is empty. Please add items to your cart before checking out.";
    exit();
}

// Get cart items from session
$cartItems = $_SESSION['cart'];

// Calculate total price
$totalPrice = 0;
foreach ($cartItems as $item) {
    $totalPrice += $item['price'] * $item['quantity']; // Assuming price and quantity always exist
}

// Check if form is submitted
if (isset($_REQUEST['submit'])) { // Check if the form is submitted
    // Use $_REQUEST to get user details from the form
    $userid = $_REQUEST['user_id']; // Using $_REQUEST to handle input
    $shippingAddress = $_REQUEST['address'];
    $finalPrice = $_REQUEST['total_price'];
    $alternativeMobileNo = $_REQUEST['alternative_mobile_no'];
    $status = "Pending"; // Default status
    $orderDate = date("Y-m-d"); // Current date

    // Payment details
    $cardName = $_REQUEST['card_name'];
    $cardNumber = $_REQUEST['card_number'];

    $cvv = $_REQUEST['cvv'];

    // Validate payment details here (add your validation logic)

    // Insert each product as a separate order
    foreach ($cartItems as $productId => $item) {
        $quantity = $item['quantity']; // Accessing quantity directly
        $price = $item['price']; // Accessing price directly

        // Insert order into the orders table for each product
        $orderQuery = "INSERT INTO orders (userid, productid, shippingaddress, finalprice, alternativemobileno, status, order_date)
                       VALUES ('$userid', '$productId', '$shippingAddress', '$finalPrice', '$alternativeMobileNo', '$status', '$orderDate')";

        if ($conn->query($orderQuery) === TRUE) {
            $orderId = $conn->insert_id; // Get the ID of the inserted order (if needed)

            // Insert payment details into payment table
            $paymentQuery = "INSERT INTO payment(card_name, card_number, cvv, total_amount, created_at)
                             VALUES ('$cardName', '$cardNumber', '$cvv', '$finalPrice', NOW())";

            if ($conn->query($paymentQuery) === TRUE) {
                $paymentId = $conn->insert_id; // Get the payment ID
                // Update order with payment ID
                $updateOrderQuery = "UPDATE orders SET payid = '$paymentId' WHERE orderid = '$orderId'";
                $conn->query($updateOrderQuery);
            } else {
                echo "Error inserting payment: " . $conn->error;
            }
        } else {
            echo "Error inserting order: " . $conn->error;
        }
    }

    // Clear the cart after placing the order
    unset($_SESSION['cart']);

    // Redirect to order confirmation page
    header("Location: order_detail.php?order_id=" . $orderId);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .header {
            background-color: #131921;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            color: #333;
        }
        .cart-summary {
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .cart-item img {
            width: 100px; /* Increased size for visibility */
            height: 100px; /* Increased size for visibility */
            margin-right: 20px;
        }
        .cart-item-details {
            flex: 1;
        }
        .cart-item-price, .cart-item-quantity, .cart-item-total {
            margin: 5px 0;
        }
        .total-price {
            font-weight: bold;
            font-size: 1.5em;
            margin: 20px 0;
        }
        .form-container {
            background: #f9f9f9;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input[type="text"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #f0c14b; /* Amazon's yellow color */
            border-color: #a18e38; /* Darker yellow for border */
            color: #111;
            cursor: pointer;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background-color: #ddb347; /* Darker yellow on hover */
        }
        select {
    width: 100%;
    padding: 10px;
    margin: 5px 0 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; /* Ensures padding is included in width */
    background-color: #f9f9f9; /* Light background color */
    font-size: 16px; /* Font size for the select box */
    transition: border-color 0.3s ease; /* Smooth transition for border color */
}

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Checkout</h1>
    </div>
    <div class="container">
        <div class="cart-summary">
            <h2>Cart Summary</h2>
            <?php 
            // Assuming cart items are in session
            if (count($cartItems) > 0) {
                foreach ($cartItems as $productId => $item) {
                    // Create a row array similar to fetched database results
                    $row = [
                        'id' => $productId,
                        'name' => $item['name'],
                        'image' => $item['image'],
                        'price' => $item['price'],
                        'quantity' => $item['quantity'],
                    ];
                    echo "<div class='cart-item'>
                            <img src='images/{$row['image']}' alt='{$row['name']}'>
                            <div class='cart-item-details'>
                                <h4>{$row['name']}</h4>
                                <div class='cart-item-price'>Price: ₹{$row['price']}</div>
                                <div class='cart-item-quantity'>Quantity: {$row['quantity']}</div>
                                <hr>
                                <div class='cart-item-total'>Total: ₹" . ($row['price'] * $row['quantity']) . "</div>
                            </div>
                        </div>";
                }
            } else {
                echo "<p>No items in the cart.</p>";
            }
            ?>
        </div>

        <div class="total-price">
            <h2>Total Price: ₹<?php echo number_format($totalPrice, 2); ?></h2>
        </div>

        <div class="form-container">
            <h2>Shipping Details</h2>
            <form action="" method="post">
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>"> <!-- Include user ID -->
                <label for="address">Shipping Address:</label>
                <input type="text" name="address" required>

                <input type="hidden" name="total_price" value="<?php echo $totalPrice; ?>">

                <label for="alternative_mobile_no">Alternative Mobile No:</label>
                <input type="text" name="alternative_mobile_no">

                <h2>Payment Details</h2>
                
                <label for="card_name">Card Type:</label>
        <select name="card_name" required>
            <option value="">Select Card Type</option>
            <option value="Visa">Visa</option>
            <option value="MasterCard">MasterCard</option>
            <option value="American Express">PayPal</option>
         
        </select>


                <label for="card_number">Card Number:</label>
                <input type="text" name="card_number" required>


                <label for="cvv">CVV:</label>
                <input type="text" name="cvv" required>

                <input type="submit" name="submit" value="Place Order">
            </form>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Online Gift Shop</p>
    </footer>
</body>
</html>
