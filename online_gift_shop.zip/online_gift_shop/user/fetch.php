<?php
include "db.php";

if (isset($_POST['query'])) {
    $query = $conn->real_escape_string($_POST['query']);
    
    // Prepare SQL to fetch products matching the search query
    $sql = "SELECT * FROM product WHERE product_name LIKE '%$query%' LIMIT 10"; // Adjust table and column names as necessary
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div style="padding: 10px; border-bottom: 1px solid #ccc;">';
            echo '<strong>' . htmlspecialchars($row['product_name']) . '</strong><br>'; // Adjust product_name as necessary
            echo 'Price: $' . htmlspecialchars($row['price']); // Adjust price as necessary
            echo '</div>';
        }
    } else {
        echo '<div style="padding: 10px;">No results found.</div>';
    }
} else {
    echo '<div style="padding: 10px;">Invalid request.</div>';
}

// Close connection
$conn->close();
?>
