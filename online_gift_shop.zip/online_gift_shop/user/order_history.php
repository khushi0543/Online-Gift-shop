<?php
session_start();

// Check if user is logged in


$userid = $_SESSION['user_id']; // Assuming user_id is stored in the session

include "db.php"; // Make sure this file exists and has the correct DB credentials

// Check if the database connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL query to retrieve user's orders
$sql = "SELECT * FROM orders WHERE userid = ? ORDER BY order_date DESC";
$stmt = $conn->prepare($sql);

// Check if the SQL statement was prepared successfully
if ($stmt === false) {
    die("SQL error: " . $conn->error);
}

// Bind the user ID to the query and execute
$stmt->bind_param("s", $userid);
$stmt->execute();
$result = $stmt->get_result(); // Get the result set

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Order History</h2>
    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product ID</th>
                    <th>Shipping Address</th>
                    <th>Final Price</th>
                    <th>Status</th>
                    <th>Order Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['orderid']; ?></td>
                        <td><?php echo $row['productid']; ?></td>
                        <td><?php echo $row['shippingaddress']; ?></td>
                        <td>$<?php echo number_format($row['finalprice'], 2); ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['order_date']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No orders found.</p>
    <?php endif; ?>
</div>

</body>
</html>

<?php
$stmt->close(); // Close the statement
$conn->close(); // Close the connection
?>
