<?php
session_start(); // Start the session
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }

        .profile-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            margin: 50px auto;
        }

        .profile-container h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .profile-info {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        .profile-info label {
            font-weight: bold;
            color: #555;
        }

        .profile-info span {
            margin-left: 10px;
            color: #777;
        }

        .btn-logout {
            margin-top: 20px;
            background-color: #c7512f; /* Amazon-like logout button color */
            color: #fff;
            border-radius: 5px;
        }

        .btn-logout:hover {
            background-color: #a74426; /* Darker shade on hover */
        }
    </style>
</head>
<body>

<div class="profile-container">
    <h3>User Profile</h3>

    <div class="profile-info">
        <label>Name:</label>
        <span><?php echo $_SESSION['user_name']; ?></span>
    </div>

    <div class="profile-info">
        <label>Email:</label>
        <span><?php echo $_SESSION['user_email']; ?></span>
    </div>

    <!-- Add more profile information if available -->
    <div class="profile-info">
        <label>Contact Number:</label>
        <span><?php echo $_SESSION['contact_number'] ?? 'N/A'; ?></span> <!-- Use 'N/A' if contact number is not set -->
    </div>

    <div class="profile-info">
        <label>Address:</label>
        <span><?php echo $_SESSION['user_address'] ?? 'N/A'; ?></span> <!-- Use 'N/A' if address is not set -->
    </div>

    <a href="logout.php" class="btn btn-logout w-100">Logout</a>
</div>

<script src="../bs/js/bootstrap.bundle.min.js"></script>
</body>
</html>
