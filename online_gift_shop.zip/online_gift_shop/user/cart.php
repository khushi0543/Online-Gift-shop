<?php

include "u_header.php";
include "u_category.php";

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_name'])) {
    // Allow "View Detail" for logged-in users
    echo '<a href="product_detail.php?id=' . $row['productid'] . '" class="btn btn-custom">View Detail</a>';
} else {
    // Show "Login Required" for guests
    echo '<a href="login.php" class="btn btn-custom">Login Required</a>';
}


ob_start();
// Check if there are any products in the cart
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<div class='container text-center mt-5'><h2>Your cart is empty.</h2><a href='index.php' class='btn btn-primary mt-3'>Continue Shopping</a></div>";
} else {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Cart</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #f8f9fa;
            }
            .container {
                margin-top: 50px;
            }
            .table th, .table td {
                vertical-align: middle;
            }
            .total-row {
                font-size: 1.5rem;
                font-weight: bold;
                color: #b12704;
            }
            .cart-footer {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-top: 20px;
            }
            .product-img {
                width: 100px;
                height: auto;
            }
            .btn-success {
                background-color: #28a745;
                border-color: #28a745;
            }
            .btn-primary {
                background-color: #007bff;
                border-color: #007bff;
            }
            .btn-danger {
                background-color: #dc3545;
                border-color: #dc3545;
            }
        </style>
    </head>
    <body>

    <div class="container">
        <h2 class="text-center mb-4">Your Cart</h2>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Product Image</th>
                    <th>Product Details</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $total = 0;
            foreach ($_SESSION['cart'] as $productId => $item) {
                $itemTotal = $item['price'] * $item['quantity'];
                $total += $itemTotal;
                echo "<tr>
                        <td><img src='images/{$item['image']}' class='product-img' alt='{$item['name']}'></td>
                        <td>
                            <strong>{$item['name']}</strong><br>
                        </td>
                        <td>\${$item['price']}</td>
                        <td>{$item['quantity']}</td>
                        <td>₹{$itemTotal}</td>
                        <td>
                            <a href='remove_from_cart.php?id={$productId}' class='btn btn-danger btn-sm'>Remove</a>
                        </td>
                    </tr>";
            }
            ?>
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <td colspan="4" class="text-right">Total Amount</td>
                    <td>&#8377;<?php echo number_format($total, 2); ?></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>

        <div class="cart-footer">
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
            <a href="checkout.php" class="btn btn-success">Proceed to Buy</a>
        </div>
    </div>
    <br><br><br><br>
    </body>
    </html>
    <?php
    include "footer.php";
}
?>
