<?php 

require '../admin/db.php'; // Include your database connection
session_start(); // Start session to access user details

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Orders</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            background-color: #ecf0f5;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 24px;
            margin: 0;
            color: #333;
        }

        .order-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .order-table th, .order-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .order-table th {
            background-color: #f8f8f8;
            color: #333;
            text-transform: uppercase;
        }

        .order-table td a {
            color: #007bff;
            text-decoration: none;
        }

        .order-table td a:hover {
            color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>Your Orders</h1>
        </header>
        <br><br><br>

        <?php
        // Query to select all orders for the logged-in user
        $q = "SELECT orders.order_id, product.name AS product_name, product.regularprice AS price, orders.quantity, orders.total_price, orders.order_date
              FROM orders
              JOIN product ON orders.product_id = product.productid
              WHERE orders.customer_id = $user_id";
        $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
        $nor = mysqli_num_rows($res);

        // If there are orders, display them in a table
        if ($nor > 0) {
            echo "<table class='order-table'>";
            echo "<tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                </tr>";

            // Fetch each order and display it
            while ($r = mysqli_fetch_assoc($res)) {
                echo "<tr>
                        <td>{$r['order_id']}</td>
                        <td>{$r['product_name']}</td>
                        <td>{$r['price']}</td>
                        <td>{$r['quantity']}</td>
                        <td>{$r['total_price']}</td>
                        <td>{$r['order_date']}</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='message'>No orders found.</p>";
        }

        // Display messages if present
        if (isset($_REQUEST['msg'])) {
            echo "<div class='message'>" . $_REQUEST['msg'] . "</div>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
