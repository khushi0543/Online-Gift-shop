<?php
session_start(); // Start the session

include 'db.php'; 

// Fetch user_id from session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Fetch orders for the given user_id
    $query = "SELECT * FROM orders WHERE userid = '$user_id' ORDER BY order_date DESC";
    $result = mysqli_query($conn, $query);

    echo "<h1>Your Orders</h1>";

    if (mysqli_num_rows($result) > 0) {
        // Display the orders in a table
        echo "<table border='1'>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total Price</th>
                </tr>";

        // Fetch rows and display them
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['orderid']}</td>
                    <td>{$row['order_date']}</td>
                    <td>{$row['status']}</td>
                    <td>{$row['finalprice']}</td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No orders found for this user.</p>";
    }
} else {
    echo "<p>User not logged in. Please log in to view your orders.</p>";
}
?>
