<?php
include "db.php";


// Get sorting criteria and category from the request
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : '';
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';

// Initialize the query
$query = "SELECT productid, name, image, regularprice, saleprice,color_id FROM product";

// Add category filtering if selected
if (!empty($category_filter)) {
    $query .= " WHERE category = '$category_filter'";
}

// Add sorting to the query based on the user's selection
switch ($sort_by) {
    case 'price_asc':
        $query .= " ORDER BY regularprice ASC";
        break;
    case 'price_desc':
        $query .= " ORDER BY regularprice DESC";
        break;
    case 'color':
        $query .= " ORDER BY color_id"; 
        break;
    case 'category':
        $query .= " ORDER BY category_id"; 
        break;
    default:
        break;
}

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Cards</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
  .shop-section {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between; /* Use space-between for even distribution */
    background-color: #f0f0f0; /* Slightly lighter background */
    padding: 20px;
}

.box {
    height: 500px; /* Adjust height for a more compact look */
    width: 23%; /* Width of each box */
    background-color: white;
    padding: 15px;
    margin: 10px; /* Reduced margin */
    border-radius: 5px; /* Smaller border-radius */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Softer shadow */
    transition: transform 0.2s ease-in-out; /* Smooth hover effect */
    position: relative;
}

.box:hover {
    transform: translateY(-5px); /* Slight lift on hover */
}

.box-img {
    height: 350px; /* Increased height for the image */
    background-size: cover; /* Use cover to maintain aspect ratio */
    background-repeat: no-repeat; /* Prevent image repeat */
    background-position: center; /* Center the image */
    margin-bottom: 10px; /* Space below image */
    border-radius: 5px; /* Rounded corners */
}


.box-content {
    text-align: left; /* Align text to the left */
}

.card-title {
    font-size: 1.15rem; /* Smaller font size */
    font-weight: bold;
    margin-bottom: 5px; /* Reduced margin */
}

.price {
    font-size: 1.2rem; /* Smaller font size for price */
    color: #B12704; /* Amazon red color for price */
    margin-bottom: 10px; /* Margin below price */
}

.btn-custom {
    background-color: #ff9900; /* Amazon orange color */
    color: white;
    border-radius: 4px;
    margin-top: 5px; /* Reduced margin */
    transition: background-color 0.3s;
}

.btn-custom:hover {
    background-color: #e68a00; /* Darker shade for hover */
}

.btn-outline-danger {
    margin-top: 5px; /* Reduced margin */
}

.no-products {
    text-align: center;
    color: #d9534f; /* Bootstrap danger color */
    font-size: 1.5rem;
}

    </style>
</head>
<body>
    <div class="container-fluid"> <!-- Use container-fluid for full width -->
        <div class="row">
            <div class="col-sm-2">
                <div class="product-list">
                    <h3>Product Categories</h3>
                    <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"> <!-- Change to your current page -->
                        <div class="form-group">
                            <label for="sort-by">Sort By:</label>
                            <select name="sort_by" id="sort-by" class="form-control" onchange="this.form.submit()">
                                <option value="">Select Sorting</option>
                                <option value="price_asc" <?php if ($sort_by == 'price_asc') echo 'selected'; ?>>Price: Low to High</option>
                                <option value="price_desc" <?php if ($sort_by == 'price_desc') echo 'selected'; ?>>Price: High to Low</option>
                                <option value="color" <?php if ($sort_by == 'color') echo 'selected'; ?>>Color</option>
                                <option value="category" <?php if ($sort_by == 'category') echo 'selected'; ?>>Category</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-9">
            <div class="shop-section" id="product-container">
    <?php
    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="box">';
                echo '<a href="product_detail.php?id=' . $row['productid'] . '">';
                echo '<div class="box-img" style="background-image: url(images/' . $row['image'] . ');"></div>';
                echo '</a>'; 
                
                echo '<div class="box-content">';
                echo '<h2 class="card-title">' . $row['name'] . '</h2>';
                echo '<h3 class="price">₹' . number_format($row['regularprice'], 2) . '</h3>';
                
                // Wishlist Icon Link
                echo '<a href="wishlist_insert.php?id=' . $row['productid'] . '" class="btn btn-outline-danger btn-sm float-right">'; 
                echo '<i class="fas fa-heart"></i>';
                echo '</a>';
                
                // Check if the user is logged in
                if (isset($_SESSION['user_name'])) {
                    // Allow "View Detail" for logged-in users
                    echo '<a href="add_to_cart.php?id=' . $row['productid'] . '" class="btn btn-custom">Add To Cart</a>';
                } else {
                    // Show "Login Required" for guests
                    echo '<a href="login.php" class="btn btn-custom">Login Required</a>';
                }

                echo '</div>'; // box-content
                echo '</div>'; // box
            }
        } else {
            echo "<p class='no-products'>No products found.</p>";
        }

        mysqli_free_result($result);
    } else {
        echo "<p class='no-products'>Error: " . mysqli_error($conn) . "</p>";
    }

    mysqli_close($conn);
    ?>
</div>

            </div>
        </div>
    </div>
</body>
</html>
