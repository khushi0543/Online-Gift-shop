<?php
session_start();
include "db.php"; // Ensure this file contains your database connection logic

// Fetch categories from the database
$sql = "SELECT id AS category_id, categoryname AS category_name FROM category";
$result = mysqli_query($conn, $sql);

if ($result === false) {
    die("SQL error: " . mysqli_error($conn));
}

$categories = [];
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Gift Shop</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .margin-div {
            margin: 10px; /* Adjust the margin value as needed */
        }
        .product {
            border: 1px solid #ddd;
            padding: 10px;
            margin: 10px;
            border-radius: 5px;
        }
        .product img {
            max-width: 100px; /* Adjust based on your design */
            height: auto;
        }
    </style>
    <script>
        $(document).ready(function () {
            $('#search-bar').keyup(function () {
                var query = $(this).val();

                $.ajax({
                    url: 'search_products.php',  // Search handling PHP script
                    method: 'POST',
                    data: { query: query },
                    success: function (data) {
                        $('#product-container').html(data);  // Update search results
                    }
                });
            });
        });
    </script>
</head>

<body>
    <header style="width: 100%; background-color: #232F3E;">
        <nav style="height: 80px; display: flex; align-items: center; justify-content: space-between; color: #fff; max-width: 1280px; margin: 0 auto; padding: 0 20px;">
            <!-- Logo -->
            <div class="nav-logo margin-div" style="flex-shrink: 0; margin-left: -200px;">
                <a href="#"><img src="./images/l.png" alt="Logo" style="height: 70px; width: 100px;"></a>
            </div>

            <!-- Address -->
            <div class="address margin-div" style="display: flex; align-items: center; margin-left: 30px;">
                <i class="fa fa-map-marker" aria-hidden="true" style="color: #fff; margin-right: 8px; font-size: 1.8rem;"></i>
                <div style="display: flex; flex-direction: column;">
                    <a href="#" style="font-size: 1.1rem; color: #ccc; text-decoration: none;">Deliver to</a>
                    <a href="#" style="font-size: 1.3rem; color: #fff; text-decoration: none;">395004</a>
                </div>
            </div>

            <!-- Search bar -->
            <div class="nav-search margin-div" style="display: flex; justify-content: space-evenly; max-width: 700px; width: 100%; height: 50px; border-radius: 4px; overflow: hidden;">
                <select style="background: #f3f3f3; border: none; padding: 10px; font-size: 1rem; border-radius: 4px; margin-right: -5px;">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category_id']; ?>">
                            <?php echo $category['category_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="text" id="search-bar" placeholder="Search Products" style="max-width: 600px; width: 100%; font-size: 1.2rem; border: none; outline: none; padding: 10px;">
                <div class="search-icon" style="width: 50px; display: flex; justify-content: center; align-items: center; font-size: 1.8rem; background: #febd68; color: #000; cursor: pointer;">
                    <i class="fa fa-search"></i>
                </div>
            </div>

            <!-- User Authentication Links -->
            <div class="sign-in margin-div" style="display: flex; align-items: center; margin-right: -50px;">
                <?php if (isset($_SESSION['user_name'])) { ?>
                    <div style="color: #fff; display: flex; align-items: center; margin-right: 20px;">
                        <i class="fas fa-user" style="margin-right: 5px; font-size: 1.5rem;"></i>
                        <span>Hello, <h4><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4></span>
                        <a href="profile.php" style="color: #fff; margin-left: 25px;">
                            <i class="fas fa-user-circle" style="margin-right: 5px; font-size: 1.5rem;"></i> Profile
                        </a>&nbsp;&nbsp;&nbsp;
                        <a href="logout.php" style="color: #fff; margin-left: 25px;">
                            <i class="fas fa-sign-out-alt" style="margin-right: 5px; font-size: 1.5rem;"></i> Logout
                        </a>
                    </div>
                <?php } else { ?>
                    <a href="login.php" style="text-decoration: none; ">
                        <button style="background-color: #febd68; padding: 12px 24px; border: none; border-radius: 5px; font-size: 1.1rem; cursor: pointer; color: #000; font-weight: bold; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); transition: background-color 0.3s, transform 0.3s; margin: 5px 0; outline: none;">
                        Sign In</button>
                    </a>
                <?php } ?>
            </div>

            <!-- Wishlist, Cart, and Order Links -->
            <div class="nav-links margin-div" style="display: flex; align-items: center;">
                <div class="wishlist" style="margin-left: 40px;">
                    <a href="view_wishlist.php" style="color: #fff; text-decoration: none;">
                        <i class="fa fa-heart" style="margin-right: 5px; font-size: 1.8rem;"></i> Wishlist
                    </a>
                </div>
                <div class="cart" style="margin-left: 40px;">
                    <a href="cart.php" style="color: #fff; text-decoration: none;">
                        <i class="fa fa-shopping-cart" style="margin-right: 5px; font-size: 1.8rem;"></i> Cart
                    </a>
                </div>
                <div class="order-details" style="margin-left: 40px;">
                    <a href="order_detail.php" style="color: #fff; text-decoration: none;">
                        <i class="fa fa-box" style="margin-right: 5px; font-size: 1.8rem;"></i> Orders
                    </a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Product Container for Search Results -->
    <div id="product-container" ></div>

</body>
</html>
