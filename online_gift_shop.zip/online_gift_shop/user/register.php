<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="style.css" />
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: #fff;
        }

        .container {
            text-align: center;
        }

        h1 {
            color: white;
            font-family: Arial, sans-serif;
            font-size: 3em;
        }

        .container {
            position: relative;
            max-width: 700px;
            width: 100%;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .header {
            background-color: #111;
            color: #fff;
            padding: 15px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            width: 100%;
        }

        .header .logo img {
            height: 40px;
        }

        .header .site-title {
            font-size: 24px;
            font-weight: bold;
        }

        .header .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .input-box label {
            color: #333;
        }

        .form :where(.input-box input, .select-box) {
            position: relative;
            height: 50px;
            width: 100%;
            outline: none;
            font-size: 1rem;
            color: #707070;
            margin-top: 8px;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 0 15px;
        }

        .form button {
            height: 55px;
            width: 100%;
            color: #fff;
            font-size: 1rem;
            font-weight: 400;
            margin-top: 30px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            background: rgb(130, 106, 251);
        }
    </style>
</head>

<body>

    <header class="header">
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <div class="site-title">
            Online Gift Shop
        </div>
        <div class="user-info"></div>
    </header>

    <section class="container">
        <header>Registration Form</header>
        <form action="" method="POST" class="form">
            <div class="input-box">
                <label>Full Name</label>
                <input type="text" name="name" placeholder="Enter full name" required />
            </div>
            <div class="input-box">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="Enter email address" required />
            </div>
            <div class="input-box">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter password" required />
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Phone Number</label>
                    <input type="tel" name="phoneno" placeholder="Enter phone number" required />
                </div>
                <div class="input-box">
                    <label>Birth Date</label>
                    <input type="date" name="birthdate" required />
                </div>
            </div>
            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" value="male" checked />
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="female" />
                        <label for="check-female">Female</label>
                    </div>
                </div>
            </div>
            <div class="input-box address">
                <label>Address</label>
                <input type="text" name="address" placeholder="Enter street address" required />
                <div class="column">
                    <input type="number" name="pincode" placeholder="Enter postal code" required />
                </div>
            </div>
            <input type="hidden" name="lastLogin" value="<?php echo date('Y-m-d H:i:s'); ?>">
            <div>
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </section>

    <?php
    if (isset($_REQUEST['submit'])) {
        $name = $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $phoneno = $_REQUEST['phoneno'];
        $birthdate = $_REQUEST['birthdate'];
        $gender = $_REQUEST['gender'];
        $address = $_REQUEST['address'];
        $pincode = $_REQUEST['pincode'];
        $lastLogin = $_REQUEST['lastLogin'];

        require 'db.php';

        $q = "INSERT INTO users VALUES (null, '$name', '$email', '$password', '$phoneno', '$birthdate', '$gender', '$address', '$pincode', '$lastLogin')";
        
        if (mysqli_query($conn, $q)) {
            $_SESSION['email'] = $email;
            header("Location: login.php");
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
    ?>
</body>

</html>
