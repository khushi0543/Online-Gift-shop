<?php
include "u_header.php";
include "u_category.php";
require "db.php"; 

// Check if the product ID is set in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $productId = $_GET['id']; // Get the product ID from the URL

    // Query to fetch product details along with brand, color, size, and category
    $sql = "
    SELECT p.*, 
           b.brandname AS brand_name, 
           c.colorname AS color_name, 
           s.sizename AS size_name,
           cat.categoryname AS category_name 
    FROM product p
    LEFT JOIN brand b ON p.brand_id = b.id
    LEFT JOIN color c ON p.color_id = c.id
    LEFT JOIN size s ON p.size_id = s.id
    LEFT JOIN category cat ON p.category_id = cat.id
    WHERE p.productid = $productId";

    // Execute the query
    $result = mysqli_query($conn, $sql);

    // Check if the query execution was successful
    if ($result) {
        // Start HTML output
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo $product['name']; ?> - Product Details</title>
            <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
            <style>
                body {
                    background-color: #f8f9fa;
                }
                .container {
                    margin-top: 50px;
                    background: white;
                    padding: 20px;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                }
                .product-image {
                    height: 400px; 
                    object-fit: cover;
                    border-radius: 8px;
                }
                .btn-primary {
                    background-color: #007bff;
                    border-color: #007bff;
                }
                .price {
                    font-size: 1.5rem;
                    color: #b12704; 
                    margin-top: 10px;
                }
                .regular-price {
                    text-decoration: line-through;
                    color: #555;
                    margin-left: 10px;
                }
                h1 {
                    font-size: 2rem;
                    font-weight: bold;
                }
                .details {
                    margin-top: 20px;
                }
                .info {
                    margin-bottom: 15px;
                }
                .button-container {
                    margin-top: 20px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <?php
                if (mysqli_num_rows($result) > 0) {
                    $product = mysqli_fetch_assoc($result);
                    echo '<div class="row">';
                    echo '<div class="col-md-6">';
                    echo '<img src="images/' . $product['image'] . '" class="img-fluid product-image" alt="' . $product['name'] . '">';
                    echo '</div>';
                    echo '<div class="col-md-6">';
                    echo '<h1>' . $product['name'] . '</h1>';
                    echo '<p class="info"><strong>Description:</strong> ' . $product['description'] . '</p>';

                    
                        echo '<p class="price">Regular Price: ₹' . $product['regularprice'] . '</p>';
                    

                    echo '<p class="info"><strong>Quantity Available:</strong> ' . $product['qty'] . '</p>';

                    // Check if category_name exists
                    if (isset($product['category_name'])) {
                        // Only display if category is "cloth" or "purse"
                        if ($product['category_name'] == 'Fashion' || $product['category_name'] == 'purse') {
                            echo '<div class="info">';

                            // Brand Select
                            echo '<label for="brand">Brand:</label>';
                            echo '<select id="brand" class="form-control" disabled>'; // disabled to prevent user modification
                            echo '<option value="' . $product['brand_name'] . '">' . $product['brand_name'] . '</option>';
                            echo '</select>';

                            // Color Select
                            echo '<label for="color">Color:</label>';
                            echo '<select id="color" class="form-control" disabled>'; // disabled to prevent user modification
                            echo '<option value="' . $product['color_name'] . '">' . $product['color_name'] . '</option>';
                            echo '</select>';

                            // Size Select
                            echo '<label for="size">Size:</label>';
                            echo '<select id="size" class="form-control" disabled>'; // disabled to prevent user modification
                            echo '<option value="' . $product['size_name'] . '">' . $product['size_name'] . '</option>';
                            echo '</select>';

                            echo '</div>';
                        } 
                        // Check if category is "cake"
                        elseif ($product['category_name'] == 'Cake') {
                            echo '<div class="info">';

                            // Color Select
                            echo '<label for="color">Color:</label>';
                            echo '<select id="color" class="form-control" disabled>'; // disabled to prevent user modification
                            echo '<option value="' . $product['color_name'] . '">' . $product['color_name'] . '</option>';
                            echo '</select>';

                            // Flavor Select
                            echo '<label for="flavor">Flavor:</label>';
                            echo '<select id="flavor" class="form-control" disabled>'; // disabled to prevent user modification
                            echo '<option value="' . $product['flavor_name'] . '">' . $product['flavor_name'] . '</option>';
                            echo '</select>';

                            echo '</div>';
                        }
                    } else {
                        echo '<p class="info">Category information not available.</p>';
                    }

                    // Button container
                    echo '<div class="button-container">';
                    if (isset($_SESSION['user_name'])) {
                        // Allow "Add to Cart" for logged-in users
                        echo '<a href="add_to_cart.php?id=' . $product['productid'] . '" class="btn btn-primary">Add to Cart</a>'; 
                    } else {
                        // Show "Login Required" for guests
                        echo '<a href="login.php" class="btn btn-primary">By Now</a>';
                    }
                    // echo '<a href="add_to_cart.php?id=' . $product['productid'] . '" class="btn btn-primary">Add to Cart</a>'; 
                    // echo '<a href="checkout.php?id=' . $product['productid'] . '" class="btn btn-success">Buy Now</a>';
                    echo '</div>';

                    echo '</div>'; // col-md-6
                    echo '</div>'; // row
                } else {
                    echo "<p class='text-center'>Product not found.</p>";
                }

                mysqli_free_result($result);
            } else {
                // Query execution failed; display the error message
                echo "<p class='text-center'>Error fetching product details: " . mysqli_error($conn) . "</p>";
            }

            mysqli_close($conn); 
            ?>
            </div>
        </body>
        </html>
    <?php
} else {
    echo "<p class='text-center'>Invalid product ID.</p>";
}
include "footer.php";
?>
