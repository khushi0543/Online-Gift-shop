<?php
include "db.php"; // Include database connection

// Fetch all categories and their subcategories
$query = "
    SELECT c.id AS category_id, c.categoryname, 
           s.id AS subcategory_id, s.subcategoryname 
    FROM category c 
    LEFT JOIN subcategory s ON c.id = s.categoryid
";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f3f3f3; /* Light grey background similar to Amazon */
        }

        .navbar {
            background-color: #232f3e; /* Amazon dark blue navbar */
        }

        .navbar-brand,
        .nav-link {
            color: #ffffff; /* White text color for navbar items */
        }

        .dropdown-submenu {
            position: relative;
        }

        .dropdown-submenu .dropdown-menu {
            top: 0;
            left: 100%; /* Position the sub-menu to the right */
            display: none; /* Hide by default */
            background-color: #ffffff; /* White background for dropdown */
            border: 1px solid #ccc; /* Light grey border for dropdown */
        }

        .dropdown-submenu:hover .dropdown-menu {
            display: block; /* Show on hover */
        }

        .dropdown-item {
            color: #333333; /* Dark grey text for dropdown items */
        }

        .dropdown-item:hover {
            background-color: #f0c14b; /* Amazon light yellow on hover */
            color: #111; /* Darker text color on hover */
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="index.php">Home</a>
    <a class="navbar-brand" href="feedback.php">feedback</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <?php
            $currentCategoryId = null;
            if (isset($result) && mysqli_num_rows($result) > 0) { // Check if result is set and has rows
                while ($row = mysqli_fetch_array($result)) { // Use mysqli_fetch_array
                    // Check if we are in a new category
                    if ($currentCategoryId !== $row['category_id']) {
                        // Close previous subcategory list if it exists
                        if ($currentCategoryId !== null) {
                            echo '</ul></li>'; // Close the last dropdown menu
                        }

                        // Update current category
                        $currentCategoryId = $row['category_id'];
                        echo '<li class="nav-item dropdown-submenu">';
                        echo '<a class="nav-link" href="#">' . $row['categoryname'] . '</a>';
                        echo '<ul class="dropdown-menu">'; // Start new subcategory menu
                    }

                    // Only display subcategories if they exist
                    if ($row['subcategory_id']) {
                        echo '<li>';
                        echo '<a class="dropdown-item" href="product_listing.php?subcategory_id=' . $row['subcategory_id'] . '">';
                        echo $row['subcategoryname'];
                        echo '</a></li>';
                    }
                }

                // Close the last open dropdown
                if ($currentCategoryId !== null) {
                    echo '</ul></li>';
                }
            } else {
                echo '<li class="nav-item"><a class="nav-link" href="#">No categories available</a></li>';
            }
            ?>
        </ul>
    </div>
</nav>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
