<?php
include "db.php";
include "u_header.php";
include "u_category.php";

if (isset($_GET['subcategory_id'])) {
    $subcategoryId = $_GET['subcategory_id'];

    // Fetch all products under the selected subcategory
    $productQuery = "SELECT productid, name, image, regularprice FROM product WHERE subcategory_id = $subcategoryId";
    $productResult = mysqli_query($conn, $productQuery);
} else {
    echo "<p class='text-center'>No subcategory selected.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h3 class="text-center">Products</h3>
        <div class="row">
            <?php
            if ($productResult && mysqli_num_rows($productResult) > 0) {
                while ($row = mysqli_fetch_assoc($productResult)) {
                    echo '<div class="col-lg-4 col-md-6 col-sm-12 mb-4">';
                    echo '<div class="card product-card shadow-sm">';
                    echo '<a href="product_detail.php?id=' . $row['productid'] . '">';
                    echo '<div class="product-image-wrapper">';
                    echo '<img src="images/' . $row['image'] . '" class="card-img-top" alt="' . $row['name'] . '">';
                    echo '</div>';
                    echo '</a>';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . $row['name'] . '</h5>';
                    echo '<p class="card-text">Price: <span class="price">₹' . number_format($row['regularprice'], 2) . '</span></p>';
                    echo '<a href="product_detail.php?id=' . $row['productid'] . '" class="btn btn-primary">View Details</a>';
                    echo '</div>'; // Close card body
                    echo '</div>'; // Close card
                    echo '</div>'; // Close column
                }
            } else {
                echo "<p class='text-center'>No products found for this subcategory.</p>";
            }
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
include "footer.php";

?>
