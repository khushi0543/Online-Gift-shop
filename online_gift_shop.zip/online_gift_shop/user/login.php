<?php
session_start(); // Start the session at the beginning
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <script src="../bs/sweetalert.js"></script>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
        }

        .header {
            background-color: #111;
            color: #fff;
            padding: 15px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
        }

        .header .logo img {
            height: 40px;
        }

        .header .site-title {
            font-size: 24px;
            font-weight: bold;
        }

        .header .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header .user-info a {
            color: #ccc;
        }

        .header .user-info a:hover {
            color: #fff;
        }

        .login_form {
            background: #fff;
            border-radius: 6px;
            padding: 40px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
            max-width: 400px;
            width: 100%;
        }

        .login_form h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sign_up {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <header class="header">
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <div class="site-title">
            Online Gift Shop
        </div>
        <div class="user-info">
            <!-- User info section -->
        </div>
    </header>

    <div class="login_form">
        <form action="" method="post"> <!-- Form action set to current page -->
            <h3>Sign In</h3>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" class="form-control" name="email" placeholder="Enter email address" required>
            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between">
                    <label for="password" class="form-label">Password</label>
                    <a href="forgotpassword.php">Forgot Password?</a>
                </div>
                <input type="password" id="password" class="form-control" name="password" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100" name="login">Sign In</button>

            <p class="sign_up">Don't have an account? <a href="register.php">Sign Up</a></p>
        </form>
    </div>

    <script src="../bs/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
if (isset($_REQUEST['login'])) {
    $eid = $_REQUEST['email'];
    $pwd = $_REQUEST['password'];

    require "db.php";

    // Check if the user exists
    $q = "SELECT * FROM users WHERE email='$eid' AND password='$pwd'";
    $res = mysqli_query($conn, $q);
    $nor = mysqli_num_rows($res);

    if ($nor > 0) {
        $row = mysqli_fetch_assoc($res);
        $_SESSION['user_id'] = $row['user_id']; // Store user ID in session
        $_SESSION['user_email'] = $row['email']; // Storing email in session
        $_SESSION['user_name'] = $row['name']; // Storing user name in session
        
        // Redirect to index or dashboard after login
        header("Location: index.php");
        exit();
    } else {
        echo "<script>alert('Invalid email or password');</script>";
    }
}
?>
