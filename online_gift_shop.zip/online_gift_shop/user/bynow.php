<?php
session_start(); // Start the session
require "db.php";  // Include your database connection

// Check if the product ID is set in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $productId = $_GET['id']; // Get the product ID from the URL

    // Query to fetch product details
    $sql = "SELECT * FROM product WHERE productid = $productId";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
        // Prepare the order details
        $orderDetails = [
            'name' => $product['name'],
            'description' => $product['description'],
            'price' => $product['saleprice'] ?? $product['regularprice'], // Use sale price if available
            'image' => $product['image'],
            'quantity' => 1 // Assuming quantity is 1 for the "Buy Now" action
        ];
    } else {
        echo "<p class='text-center'>Product not found.</p>";
        exit;
    }
} else {
    echo "<p class='text-center'>Invalid product ID.</p>";
    exit;
}

// Start HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Information</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 100px;
        }
        .product-image {
            height: 400px; 
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Order Information</h2>
        <div class="row">
            <div class="col-md-6">
                <img src="images/<?php echo $orderDetails['image']; ?>" class="img-fluid product-image" alt="<?php echo $orderDetails['name']; ?>">
            </div>
            <div class="col-md-6">
                <h1><?php echo $orderDetails['name']; ?></h1>
                <p><strong>Description:</strong> <?php echo $orderDetails['description']; ?></p>
                <p class="price">Price: $<?php echo $orderDetails['price']; ?></p>
                <p><strong>Quantity:</strong> <?php echo $orderDetails['quantity']; ?></p>
                
                <!-- Add confirmation button -->
                <form action="process_order.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                    <input type="hidden" name="quantity" value="<?php echo $orderDetails['quantity']; ?>">
                    <button type="submit" class="btn btn-success">Confirm Purchase</button>
                </form>

                <a href="card.php" class="btn btn-primary">Continue Shopping</a>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Free the result and close the connection
mysqli_free_result($result);
mysqli_close($conn);
?>
