<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['u_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php'; // Optional, if you want a sidebar
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home Page</title>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .header-buttons.left {
            left: 20px;
        }

        .header-buttons.right {
            right: 20px;
        }

        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
        }

        .header-buttons a:hover {
            background-color: #333;
        }

        .content {
            margin: 0;
            padding: 20px;
            flex: 1;
        }

        main {
            padding: 20px;
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #f4f4f4;
            border: 2px solid gray;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #fff;
            text-transform: uppercase;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        .button {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button.delete {
            background-color: #e74c3c;
        }

        .button:hover {
            background-color: #333;
        }

        .button.delete:hover {
            background-color: #c9302c;
        }

        footer {
            background-color: #ecf0f5;
            color: #000;
            padding: 10px;
            text-align: center;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
            margin-top: auto;
        }
    </style>
</head>

<body>
    <header>
        <a href="javascript:history.back()" class="header-buttons left"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
        <h1>Welcome to the User Home Page</h1>
        <div class="header-buttons right">
            <a href="addproduct.php" class="button">Add Product</a>
        </div>
    </header>

    <div class="content">
        <main>
            <h2>Your Products</h2>
            <table>
                <tr>
                    <th>Product Name</th>
                    <th>Brand</th>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Color</th>
                    <th>Size</th>
                    <th>Quantity</th>
                    <th>Regular Price</th>
                    <th>Sale Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
                <?php
                require 'db.php';

                $sql = "SELECT p.productid, p.name AS product_name, b.brandname, c.categoryname, sub.subcategoryname, co.colorname, s.sizename, p.qty, p.regularprice, p.saleprice, p.description, p.image
                        FROM product p
                        LEFT JOIN brand b ON p.brand_id = b.id
                        LEFT JOIN category c ON p.category_id = c.id
                        LEFT JOIN size s ON p.size_id = s.id
                        LEFT JOIN color co ON p.color_id = co.id
                        LEFT JOIN subcategory sub ON p.subcategory_id = sub.id";
                $res = mysqli_query($conn, $sql);

                if ($res->num_rows > 0) {
                    while ($row = $res->fetch_assoc()) {
                        $id = $row['productid'];
                        $name = $row['product_name'];
                        $brand = $row['brandname'];
                        $category = $row['categoryname'];
                        $subcategory = $row['subcategoryname'];
                        $color = $row['colorname'];
                        $size = $row['sizename'];
                        $quantity = $row['qty'];
                        $regular_price = $row['regularprice'];
                        $sale_price = $row['saleprice'];
                        $description = $row['description'];
                        $image = $row['image'];

                        echo "<tr>";
                        echo "<td>$name</td>";
                        echo "<td>$brand</td>";
                        echo "<td>$category</td>";
                        echo "<td>$subcategory</td>";
                        echo "<td>$color</td>";
                        echo "<td>$size</td>";
                        echo "<td>$quantity</td>";
                        echo "<td>$regular_price</td>";
                        echo "<td>$sale_price</td>";
                        echo "<td>$description</td>";
                        echo "<td><img src='uploads/$image' alt='$name'></td>";
                        echo "<td>
                                <a href='editproduct.php?id=$id' class='button'>Edit</a> |
                                <a href='deleteproduct.php?id=$id' class='button delete'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='12'>No products found</td></tr>";
                }
                ?>
            </table>
        </main>
    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> Your Website. All Rights Reserved.
    </footer>
</body>

</html>
