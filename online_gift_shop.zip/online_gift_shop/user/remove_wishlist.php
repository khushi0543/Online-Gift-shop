<?php
// Include your database connection
include "db.php";

// Check if 'id' is set in the request
if (isset($_REQUEST['id'])) {
    $productId = $_REQUEST['id'];


    $query = "DELETE FROM wishlist WHERE product_id = $productId";


    if (mysqli_query($conn, $query)) {

        header("Location: view_wishlist.php?message=Product removed successfully");
    } else {

        header("Location: view_wishlist.php?message=Error removing product");
    }
} 

?>
