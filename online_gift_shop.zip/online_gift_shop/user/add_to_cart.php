<?php
session_start();

// Include your database connection
require "db.php";

// Get product ID from the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Query to get the product details
    $query = "SELECT * FROM product WHERE productid = $productId";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);

        // Check if the product is already in the cart
        if (isset($_SESSION['cart'][$productId])) {
            // If it exists, increase the quantity
            $_SESSION['cart'][$productId]['quantity'] += 1;
        } else {
            // If it doesn't exist, add to cart with quantity 1
            $_SESSION['cart'][$productId] = array(
                'name' => $product['name'],
                'price' => $product['saleprice'] ?? $product['regularprice'], // If sale price exists, use it
                'image' => $product['image'],
                'quantity' => 1
            );
        }

        // Redirect to cart page
        header("Location: cart.php");
        exit();
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid product ID.";
}

mysqli_close($conn);
?>
