<?php
// Include your database connection
include "u_header.php";
include "u_category.php";
include "db.php";

// Query to retrieve wishlist items
$query = "SELECT p.productid, p.name, p.regularprice, p.image FROM product p INNER JOIN wishlist w ON p.productid = w.product_id";
$result = mysqli_query($conn, $query);

// Start the table
echo '<div class="container mt-5">';
echo '<h2>Your Wishlist</h2>';
echo '<table class="table table-bordered table-striped text-center">'; // Added text-center class for center alignment
echo '<thead class="table-light">'; // Add background color for the header
echo '<tr>';
echo '<th>Image</th>';
echo '<th>Product Name</th>';
echo '<th>Price</th>';
echo '<th>Action</th>'; // Column for removing items
echo '</tr>';
echo '</thead>';
echo '<tbody>';

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Display each wishlist item in a table row
        echo '<tr>';
        echo '<td><img src="images/' . $row['image'] . '" alt="' . $row['name'] . '" class="img-thumbnail" style="height: 100px;"></td>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>₹' . $row['regularprice'] . '</td>';
        echo '<td>';
        // Add remove from wishlist link
        echo '<a href="remove_wishlist.php?id=' . $row['productid'] . '" class="btn btn-danger btn-sm">Remove</a>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="4" class="text-center">No products found in your wishlist.</td></tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>'; // Close container

// Free result set and close connection
mysqli_free_result($result);
mysqli_close($conn);
?>

<style>
    /* Custom CSS for Wishlist Table */
    body {
        background-color: #f8f9fa; /* Light gray background */
        font-family: Arial, sans-serif; /* Clean font family */
    }

    h2 {
        margin-bottom: 20px;
        font-size: 24px;
        text-align: center; /* Center the heading */
        color: #333; /* Dark color for better contrast */
    }

    .table {
        border-collapse: collapse; /* Collapse borders for a cleaner look */
        margin: 0 auto; /* Center the table horizontally */
        width: 80%; /* Set the width of the table */
    }

    .table th, .table td {
        padding: 15px; /* Padding for cells */
        text-align: center; /* Center-align text in cells */
        color: #333; /* Dark text color */
        border: 1px solid #dee2e6; /* Light border color */
    }

    .table-light {
        background-color: #f8f9fa; /* Light background for the header */
    }

    .table img {
        border-radius: 5px; /* Slight rounding of image corners */
    }

    .btn-danger {
        background-color: #dc3545; /* Bootstrap danger color */
        border-color: #dc3545; /* Consistent border color */
    }

    .btn-danger:hover {
        background-color: #c82333; /* Darker shade on hover */
        border-color: #bd2130; /* Consistent border color on hover */
    }

    .no-products {
        text-align: center;
        color: #6c757d; /* Bootstrap muted text color */
    }
</style>
<?php
include "footer.php";

?>