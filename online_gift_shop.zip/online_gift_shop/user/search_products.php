<?php
include "db.php"; // Include your database connection file

if (isset($_POST['query'])) {
    $query = $_POST['query'];

    // Prepare the SQL query to search for products based on the query
    $sql = "SELECT productid, name, image, regularprice, saleprice FROM product WHERE name LIKE ?";
    $stmt = mysqli_prepare($conn, $sql);
    $searchTerm = '%' . $query . '%'; // Wildcards for partial matches
    mysqli_stmt_bind_param($stmt, 's', $searchTerm);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="col-md-4">';
            echo '<div class="card">';
            echo '<a href="product_detail.php?id=' . $row['productid'] . '">';
            echo '<img src="images/' . $row['image'] . '" class="card-img-top" alt="' . $row['name'] . '">';
            echo '</a>';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . $row['name'] . '</h5>';
            if ($row['saleprice'] !== NULL) {
                echo '<p class="card-text">Regular Price: <span class="sale-price">₹' . number_format($row['regularprice'], 2) . '</span></p>';
                echo '<p class="card-text">Sale Price: <span class="price">₹' . number_format($row['saleprice'], 2) . '</span></p>';
            } else {
                echo '<p class="card-text">Price: <span class="price">₹' . number_format($row['regularprice'], 2) . '</span></p>';
            }
            echo '<a href="product_detail.php?id=' . $row['productid'] . '" class="btn btn-primary">View Details</a>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<p class='text-center'>No products found.</p>";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
