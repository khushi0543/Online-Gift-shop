<?php
session_start();
ob_start();

require "db.php"; // Include your database connection

if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
        $_SESSION['message'] = "Product has been removed from your cart.";
    } else {
        $_SESSION['message'] = "Product not found in your cart.";
    }
} else {
    $_SESSION['message'] = "Invalid product ID.";
}

header("Location: cart.php");
exit();
?>
