<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Footer Styling */
        .footer {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .footer .footer-section {
            margin-bottom: 20px;
        }

        .footer h3 {
            margin-top: 0;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .footer .social-media a {
            margin: 0 10px;
            font-size: 20px;
        }

        .footer .social-media a:hover {
            color: #ddd;
        }

        .footer form input[type="email"] {
            padding: 8px;
            margin-right: 10px;
            border-radius: 4px;
            border: none;
        }

        .footer form button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        .footer form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Footer Section -->
    <div class="footer">
        <!-- Subscription Section -->
        <div class="footer-section">
            <h3>Subscribe to Our Newsletter</h3>
            <p>Stay updated with our latest news and offers. Subscribe to our newsletter:</p>
            <form action="subscribe.php" method="POST">
                <input type="email" name="email" placeholder="Enter your email" required>
                <button type="submit">Subscribe</button>
            </form>
        </div>

        <!-- Contact Information Section -->
        <div class="footer-section">
            <h3>Contact Us</h3>
            <p>Email: <a href="mailto:info@example.com">giftora@gmail.com</a></p>
            <p>Phone: +123 456 7890</p>
            <p>Address: 123 ONGCStreet, Surat, India</p>
        </div>

        <!-- Social Media Links Section -->
        <div class="footer-section social-media">
            <h3>Follow Us</h3>
            <a href="https://facebook.com" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
        </div>

        <!-- Footer Bottom Section -->
        <div class="footer-section">
            <p>&copy; 2024 GiftOra. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
