<?php
session_start();
require 'db.php'; // Include your database connection file

// Initialize error and success messages
$error = '';
$success = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $product_id = $_POST['product_id']; // Assuming you pass the product_id from the product page

    // Validate form fields (basic validation)
    if (empty($name)) {
        $error = 'Name is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } elseif (empty($message)) {
        $error = 'Message is required.';
    } else {
        // Insert feedback into the database using prepared statements
        $query = "INSERT INTO feedback (name, email, message, product_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        
        if ($stmt) {
            // Bind the variables to the prepared statement
            $stmt->bind_param("sssi", $name, $email, $message, $product_id);

            // Execute the statement
            if ($stmt->execute()) {
                $success = 'Thank you for your feedback!';
            } else {
                $error = 'Error executing query: ' . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            $error = 'Error preparing query: ' . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h2>Submit Your Feedback</h2>

    <!-- Display Error Message -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Display Success Message -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <!-- Feedback Form -->
    <form method="POST" action="feedback.php">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" class="form-control" rows="4" required></textarea>
        </div>
        <!-- Add a hidden field to store the product_id -->
        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($_POST['product_id']); ?>">
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>

<?php
$conn->close();
?>
