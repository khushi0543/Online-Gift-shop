
<?php
session_start();
include "db.php"; // Database connection logic

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if order ID is provided
if (!isset($_GET['order_id'])) {
    echo "No order ID provided.";
    exit();
}

// Get the order ID from the URL and validate it
$orderId = intval($_GET['order_id']); // Ensure this is an integer

// Fetch order details from the database
$orderQuery = "SELECT o.*, p.card_name, p.card_number, p.cvv 
               FROM orders o
               LEFT JOIN payment p ON o.payid = p.id
               WHERE o.orderid = $orderId"; // Changed to o.orderid
$result = $conn->query($orderQuery);

// Check if order exists
if ($result->num_rows === 0) {
    echo "Order not found.";
    exit();
}

// Fetch the order data
$order = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS -->
    <style>
              body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .order-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .order-header {
            border-bottom: 2px solid #e7e7e7;
            margin-bottom: 15px;
            padding-bottom: 15px;
        }
        .order-details, .payment-details {
            margin: 15px 0;
        }
        .order-details p, .payment-details p {
            margin: 5px 0;
            font-size: 16px;
            color: #555;
        }
        .order-summary {
            background-color: #e8f4f8;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin: 20px 0;
        }
        .thank-you {
            margin-top: 30px;
            font-size: 18px;
            color: #4CAF50;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #2196F3;
            font-weight: bold;
            padding: 10px 15px;
            border: 1px solid #2196F3;
            border-radius: 4px;
        }
        a:hover {
            background-color: #2196F3;
            color: white;
        }
    </style>
</head>
<body>
    <div class="order-container">
        <div class="order-header">
            <h1>Order Details</h1>
            <h2>Order ID: <?php echo htmlspecialchars($order['orderid']); ?></h2>
        </div>

        <div class="order-details">
            <p><strong>User ID:</strong> <?php echo htmlspecialchars($order['userid']); ?></p>
            <p><strong>Shipping Address:</strong> <?php echo htmlspecialchars($order['shippingaddress']); ?></p>
            <p><strong>Final Price:</strong> ₹<?php echo htmlspecialchars($order['finalprice']); ?></p>
            <p><strong>Alternative Mobile No:</strong> <?php echo htmlspecialchars($order['alternativemobileno']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
        </div>

        <div class="payment-details">
            <h2>Payment Details</h2>
            <p><strong>Card Type:</strong> <?php echo htmlspecialchars($order['card_name']); ?></p>
            <p><strong>Card Number:</strong> <?php echo htmlspecialchars($order['card_number']); ?></p>
            <p><strong>CVV:</strong> <?php echo htmlspecialchars($order['cvv']); ?></p>
        </div>
        
        <div class="thank-you">
            <p>Thank you for your order!</p>
        </div>
        
        <a href="index.php">Return to Home</a>
    </div>
</body>
</html>
