<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Wishlist</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <?php
    // Include your database connection
    include "db.php";

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
        $productId = $_GET['id'];
        
        // Example: Insert into wishlist table (adjust according to your database structure)
        $query = "INSERT INTO wishlist (product_id) VALUES ('$productId')";
        $result = mysqli_query($conn, $query);

        mysqli_close($conn); // Close connection before sending the response

        // Generate JavaScript to show SweetAlert
        if ($result) {
            // Success message
            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Product added to wishlist successfully.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'index.php';
                    });
                  </script>";
        } else {
            // Error message
            echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error adding product to wishlist: " . mysqli_error($conn) . "',
                        confirmButtonText: 'OK'
                    });
                  </script>";
        }
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid request',
                    text: 'No product ID provided.',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
    ?>
</body>
</html>
