<?php
session_start(); 

require 'db.php'; 




// Fetch the logged-in user's ID from the session
$userid = $_SESSION['userid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header('Location: index.php?msg=Invalid email format');
        header("Location: login.php?msg=$msg");
    }

    // Escape email to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $email);

    // Check if the email matches the one in the user_register table for the logged-in user
    $query = "SELECT email FROM users WHERE uid = '$userid' AND email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Email matches, proceed with subscription

        // Insert the subscriber data
        $insert_query = "INSERT INTO subscribers (email) VALUES ('$email')";

        if (mysqli_query($conn, $insert_query)) {
            $msg = "Subscription successful!";
        } else {
            $msg = "Subscription failed. Please try again.";
        }
    } else {
        // If the email doesn't match
        $msg = "Email does not match your registered email.";
    }

    // Close the database connection
    mysqli_close($conn);
    
    // Redirect back to the homepage or subscription page with a message
    header("Location: index.php?msg=$msg");
    exit();
}
?>
