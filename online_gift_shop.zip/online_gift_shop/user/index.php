<?php 
include "u_header.php";
include "u_category.php";
include "card.php";
include "footer.php"
?>