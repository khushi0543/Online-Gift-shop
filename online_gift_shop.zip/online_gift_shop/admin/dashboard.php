<?php
include 'slidebar.php';
ob_start();
include 'db.php'; // Include your database connection file

// // Ensure the user is logged in (you might want to enhance this with user roles)
// if (!isset($_SESSION['user_id'])) {
//     header('Location: login.php');
//     exit();
// }

// Fetch the total number of products, orders, and feedback
$totalProductsQuery = "SELECT COUNT(*) AS total FROM product";
$totalOrdersQuery = "SELECT COUNT(*) AS total FROM orders";
$totalFeedbackQuery = "SELECT COUNT(*) AS total FROM feedback";

$totalProductsResult = mysqli_query($conn, $totalProductsQuery);
$totalOrdersResult = mysqli_query($conn, $totalOrdersQuery);
$totalFeedbackResult = mysqli_query($conn, $totalFeedbackQuery);

$totalProducts = mysqli_fetch_assoc($totalProductsResult)['total'];
$totalOrders = mysqli_fetch_assoc($totalOrdersResult)['total'];
$totalFeedback = mysqli_fetch_assoc($totalFeedbackResult)['total'];

mysqli_close($conn); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
        }
        .card {
            margin: 20px 0;
        }
        h2 {
        color: white; /* Change color of h2 to white */
    }
    h1 {
        color: white; /* Change color of h2 to white */
    }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Products</h5>
                        <p class="card-text"><?php echo $totalProducts; ?></p>
                        <a href="manage_product.php" class="btn btn-light">Manage Products</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Total Orders</h5>
                        <p class="card-text"><?php echo $totalOrders; ?></p>
                        <a href="order.php" class="btn btn-light">Manage Orders</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Total Feedback</h5>
                        <p class="card-text"><?php echo $totalFeedback; ?></p>
                        <a href="view_feedback.php" class="btn btn-light">View Feedback</a>
                    </div>
                </div>
            </div>
        </div>
        <h2>Recent Activity</h2>
        <!-- Add code here to display recent orders or feedback -->
    </div>
</body>
</html>
