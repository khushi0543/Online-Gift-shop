<?php
session_start();
require "db.php"; // Include your database connection

if (isset($_REQUEST['submit_email'])) {
    $email = $_REQUEST['email'];
    
    // Check if email exists in the database
    $query = "SELECT * FROM admin WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['reset_email'] = $email; // Store email in session
        $_SESSION['step'] = 2; // Move to password reset step
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Email does not exist.'
                });
              </script>";
    }
}

if (isset($_REQUEST['reset_password'])) {
    $new_password = $_REQUEST['password'];
    $email = $_SESSION['reset_email'];

    // Update password in the database
    $query = "UPDATE admin SET password='$new_password' WHERE email='$email'";
    if (mysqli_query($conn, $query)) {
        unset($_SESSION['reset_email']); // Clear the session variable
        unset($_SESSION['step']); // Clear the step
        // Redirect to login page after successful password reset
        header("Location: index.php"); 
        exit; // Make sure to call exit after header redirection
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating password.'
                });
              </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="../bs/sweetalert.js"></script>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; /* Light background color */
            font-family: Arial, sans-serif; /* Font for the page */
        }

        .container {
            margin-top: 100px; /* Margin from the top */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Soft shadow effect */
            background-color: white; /* White background for the form */
            padding: 30px; /* Padding inside the container */
        }

        h3 {
            color: #343a40; /* Darker color for the heading */
            margin-bottom: 30px; /* Space below the heading */
        }

        .form-label {
            font-weight: bold; /* Bold labels */
            color: #495057; /* Darker color for labels */
        }

        .btn-primary {
            background-color: #007bff; /* Bootstrap primary button color */
            border: none; /* Remove border */
            transition: background-color 0.3s ease; /* Smooth transition for hover effect */
        }

        .btn-primary:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }

        .mb-3 {
            margin-bottom: 15px; /* Space between form fields */
        }
    </style>
</head>

</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h3 class="text-center">Forgot Password</h3>

            <?php if (!isset($_SESSION['step']) || $_SESSION['step'] != 2): ?>
            <!-- Step 1: Enter Email Form -->
            <form method="post">
                <div class="mb-3">
                    <label for="email" class="form-label">Enter Your Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" name="submit_email">Submit</button>
            </form>

            <?php else: ?>
            <!-- Step 2: Reset Password Form -->
            <form method="post">
                <div class="mb-3">
                    <label for="password" class="form-label">New Password</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" name="reset_password">Reset Password</button>
            </form>
            <?php endif; ?>

        </div>
    </div>
</div>
</body>
</html>
