<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');

}

require 'db.php';

if (isset($_REQUEST['id'])) {
    $productid = $_REQUEST['id'];
    $sql = "DELETE FROM product WHERE productid='$productid'";

    if (mysqli_query($conn, $sql)) {
        header("Location: manage_product.php");
        exit();
    } else {
        die("Error deleting product: " . mysqli_error($conn));
    }
} else {
    header("Location: manage_product.php");
    exit();
}
?>
