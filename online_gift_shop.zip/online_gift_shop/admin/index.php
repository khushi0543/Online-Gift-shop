<?php
session_start();
ob_start();
include 'slidebar.php';


if (isset($_SESSION['a_email'])) {
    header('Location: slidebar.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <script src="../bs/sweetalert.js"></script>

    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
        }

        .login_form {
            background: #fff;
            border-radius: 6px;
            padding: 40px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
            max-width: 400px;
            width: 100%;
        }

        .login_form h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sign_up {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    
    <div class="login_form">
        <form action="" method="post">
            <h3>Sign In</h3>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" class="form-control" name="email" placeholder="Enter email address" required>
            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between">
                    <label for="password" class="form-label">Password</label>
                    <a href="forgotpassword.php">Forgot Password?</a>
                </div>
                <input type="password" id="password" class="form-control"  name="password" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100" name="login">Sign In</button>

            <p class="sign_up">Don't have an account? <a href="signup.php">Sign Up</a></p>
        </form>
    </div>
    
    <script src="~\bs\js\bootstrap.bundle.min.js"></script>
</body>

</html> 

<?php


if (isset($_SESSION['a_email'])) {
    header('Location: slidebar.php');
    exit();
}

if (isset($_REQUEST['login'])) {
    $eid = $_REQUEST['email'];
    $pwd = $_REQUEST['password'];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
    require "db.php";
    $q = "SELECT * FROM admin WHERE email='$eid' AND password='$pwd'";
    $res = mysqli_query($conn, $q);
    $nor = mysqli_num_rows($res);
    
    if ($nor > 0) {
        $_SESSION['a_email'] = $eid;
        // SweetAlert on successful login
        echo "<script>
                Swal.fire({
                  icon: 'success',
                  title: 'Login Successful!',
                  showConfirmButton: false,
                  timer: 1500
                }).then(() => {
                    window.location.href = 'dashboard.php'; // Redirect after alert
                });
              </script>";
    } else {
        echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Invalid Username or Password',
          text: 'Please try again',
          showConfirmButton: true
        });
      </script>";
}
    }

?>

