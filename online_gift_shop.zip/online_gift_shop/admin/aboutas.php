<?php
include 'slidebar.php'; // Ensure this includes your navigation
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Online Gift Shop</title>
    <link href="../bs/t/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .about-container {
            padding: 50px;
            color: #333;
        }

        .about-section {
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h1, h3 {
            text-align: center;
            color: #333;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
            text-align: justify;
        }

        .vision-mission {
            margin-top: 30px;
        }

        .team-section img {
            border-radius: 50%;
            max-width: 100px;
        }

        .team-member {
            text-align: center;
            margin-top: 20px;
        }

        .team-member h5 {
            margin-top: 10px;
            font-size: 18px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <?php include 'slidebar.php'; // Include your sidebar here ?>
        </div>
        <div class="col-md-9">
            <div class="container about-container">
                <div class="about-section">
                    <h1>About Us</h1>
                    <p>Welcome to our Online Gift Shop, your one-stop destination for all your gifting needs! Whether you're looking for the perfect present for a loved one, or you want to explore unique items, we offer a wide variety of products across categories such as chocolates, cards, home décor, personalized gifts, and more.</p>

                    <p>Founded in [Year], we have been dedicated to making gift shopping an easy and enjoyable experience for our customers. Our platform connects buyers and sellers from all over, making it easier for you to find special gifts no matter where you are.</p>
                </div>

                <div class="about-section vision-mission">
                    <h3>Our Vision & Mission</h3>
                    <p><strong>Vision:</strong> To become the most trusted and convenient online shopping destination for gifts worldwide, providing exceptional customer service and unique products.</p>

                    <p><strong>Mission:</strong> Our mission is to simplify gift-giving by offering an intuitive, user-friendly platform with a vast array of high-quality products. We aim to provide an enjoyable shopping experience while promoting small businesses and artisans.</p>
                </div>

                <div class="about-section">
                    <h3>What We Offer</h3>
                    <p>We specialize in a range of products, including:</p>
                    <ul>
                        <li>Customizable gifts for every occasion</li>
                        <li>Personalized items like mugs, T-shirts, and photo frames</li>
                        <li>Handcrafted gift sets and hampers</li>
                        <li>Special seasonal and festival collections</li>
                        <li>Eco-friendly gifts and sustainable options</li>
                    </ul>
                </div>

                <div class="about-section">
                    <h3>Meet Our Team</h3>
                    <div class="row team-section">
                        <div class="col-md-4">
                            <div class="team-member">
                                <img src="team1.jpg" alt="Team Member 1" class="img-fluid">
                                <h5>John Doe</h5>
                                <p>Founder & CEO</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="team-member">
                                <img src="team2.jpg" alt="Team Member 2" class="img-fluid">
                                <h5>Jane Smith</h5>
                                <p>Head of Operations</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="team-member">
                                <img src="team3.jpg" alt="Team Member 3" class="img-fluid">
                                <h5>Michael Lee</h5>
                                <p>Lead Designer</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="about-section">
                    <h3>Contact Us</h3>
                    <p>If you have any questions or need assistance, feel free to reach out to us at:</p>
                    <p><strong>Email:</strong> support@onlinegiftshop.com</p>
                    <p><strong>Phone:</strong> +1 (800) 123-4567</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../bs/js/bootstrap.bundle.min.js"></script>
</body>
</html>
