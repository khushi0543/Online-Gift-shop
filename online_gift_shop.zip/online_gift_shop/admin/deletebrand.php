<?php
require 'db.php';

// Check if the brand ID is set
if (isset($_GET['brandid'])) {
    $brandid = $_GET['brandid'];
    
    // Delete query
    $q = "DELETE FROM brand WHERE id = '$brandid'";
    print_r($q);
    if (mysqli_query($conn, $q)) {
        // Redirect with success message
        header("Location: brand.php?imsg=Brand deleted successfully!");
    } else {
        echo "Deletion Failed: " . mysqli_error($conn);
    }
} else {
    die("No brand ID provided!");
}
?>
