<?php

session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

require 'db.php';

// Get the subcategory ID from the URL
if (isset($_GET['subcategoryid'])) {
    $subcategoryid = $_GET['subcategoryid'];

    // Fetch subcategory data
    $q = "SELECT * FROM subcategory WHERE id = '$subcategoryid'";
    $res = mysqli_query($conn, $q);
    $subcategory = mysqli_fetch_assoc($res);
    
    if (!$subcategory) {
        header("Location: managesubcategory.php?umsg=Subcategory not found");
        exit;
    }
    
    // Fetch all categories for the dropdown
    $q = "SELECT * FROM category";
    $res = mysqli_query($conn, $q);
}

// Handle form submission to update subcategory
if (isset($_POST['updatesubcategory'])) {
    $categoryid = $_POST['categoryid'];
    $subcategoryname = $_POST['subcategoryname'];

    // Update query
    $q = "UPDATE subcategory SET categoryid = '$categoryid', subcategoryname = '$subcategoryname' WHERE id = '$subcategoryid'";

    if (mysqli_query($conn, $q)) {
        header("Location: subcategory.php?imsg=Subcategory updated successfully!");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Subcategory</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 10px;
        }

        input[type="text"], select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Subcategory</h2>

    <form method="POST">
        <label for="categoryid">Category:</label>
        <select name="categoryid" id="categoryid" required>
            <option value="">Select Category</option>
            <?php
            // Populate the dropdown with categories, pre-selecting the current category
            while ($row = mysqli_fetch_assoc($res)) {
                $selected = ($row['id'] == $subcategory['categoryid']) ? 'selected' : '';
                echo "<option value='" . $row['id'] . "' $selected>" . $row['categoryname'] . "</option>";
            }
            ?>
        </select>

        <label for="subcategoryname">Subcategory Name:</label>
        <input type="text" name="subcategoryname" id="subcategoryname" value="<?php echo $subcategory['subcategoryname']; ?>" required>

        <input type="submit" name="updatesubcategory" value="Update Subcategory">
    </form>
</div>

</body>
</html>
