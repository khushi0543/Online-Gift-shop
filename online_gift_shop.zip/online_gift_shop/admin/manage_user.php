<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

require 'db.php';  // Include your database connection

include 'slidebar.php'; // Include your sidebar or navigation

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Manage Users</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .user-table th, .user-table td {
            padding: 12px;
            border: 1px solid #ddd;
            color: black;
        }

        .user-table th {
            background-color: #f4f4f4;
        }

        .message {
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
            color: green;
        }

        .message.error {
            color: red;
        }

        .actions {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 style="color: black;">Manage Users</h1>

        <?php
        // Query to select all users from the users table
        $query = "SELECT uid, name, email, lastlogin FROM users"; // Updated column names
        $result = mysqli_query($conn, $query);

        // Check for SQL errors
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        // Check if there are users to display
        if (mysqli_num_rows($result) > 0) {
            echo "<table class='user-table'>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Last Login</th>
                    </tr>";

            // Fetch and display each user in the table
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$row['uid']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['lastlogin']}</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "<p class='message'>No users found.</p>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
