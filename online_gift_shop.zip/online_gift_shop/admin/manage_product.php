<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
      
        .content {
            margin-left: 270px; 
            padding: 0px;
            flex: 1;
        }

        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
        }

        header h1 {
            margin: 0;
        }

        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .header-buttons.left {
            left: 20px;
        }

        .header-buttons.right {
            right: 20px;
        }

        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
        }

        .search-bar {
            margin-bottom: 20px;
        }

        #search-input {
            width: 50%;
            padding: 20px;
            margin-top: 25px;
            margin-left: 950px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        main {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 2px solid gray;
            background-color: #f4f4f4;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #fff;
            color: #000;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        .button {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .button.delete {
            background-color: #e74c3c;
        }


    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#search-input").on("input", function() {
                var query = $(this).val();

                $.ajax({
                    url: 'searchproduct.php',
                    method: 'POST',
                    data: { query: query },
                    success: function(response) {
                        $("#result").html(response);
                    },
                    error: function() {
                        alert("An error occurred.");
                    }
                });
            });
        });
    </script>
</head>

<body>
    <div class="content">
        <header>
            <a href="javascript:history.back()" class="header-buttons left"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
            <h1>Manage Products</h1>
            <div class="header-buttons right">
                <a href="addproduct.php" class="button">Add Product</a>
            </div>
        </header>
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Search products..." />
        </div>
        <main>
            <section>
                <table>
                    <tr>
                        <th>Product Name</th>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>Subcategory</th>
                        <th>Color</th>
                        <th>Size</th>
                        <th>Quantity</th>
                        <th>Regular Price</th>
                        <th>Sale Price</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                    require 'db.php';

                    // Query to get all products
                    $sql = "SELECT p.productid, p.name AS product_name, b.brandname, c.categoryname, sub.subcategoryname, co.colorname, s.sizename, p.qty, p.regularprice, p.saleprice, p.description, p.image
                    FROM product p
                    LEFT JOIN brand b ON p.brand_id = b.id
                    LEFT JOIN category c ON p.category_id = c.id
                    LEFT JOIN size s ON p.size_id = s.id
                    LEFT JOIN color co ON p.color_id = co.id
                    LEFT JOIN subcategory sub ON p.subcategory_id = sub.id";
                    $res = mysqli_query($conn, $sql);

                    // Check if any products are returned
                    if ($res->num_rows > 0) {
                        // Output data of each row
                        while ($row = $res->fetch_assoc()) {
                            $id = $row['productid'];
                            $name = $row['product_name'];
                            $brand = $row['brandname'];
                            $category = $row['categoryname'];
                            $subcategory = $row['subcategoryname'];
                            $color = $row['colorname'];
                            $size = $row['sizename'];
                            $quantity = $row['qty'];
                            $regular_price = $row['regularprice'];
                            $sale_price = $row['saleprice'];
                            $description = $row['description'];
                            $image = $row['image'];

                            echo "<tr>";
                            echo "<td>$name</td>";
                            echo "<td>$brand</td>";
                            echo "<td>$category</td>";
                            echo "<td>$subcategory</td>";
                            echo "<td>$color</td>";
                            echo "<td>$size</td>";
                            echo "<td>$quantity</td>";
                            echo "<td>$regular_price</td>";
                            echo "<td>$sale_price</td>";
                            echo "<td>$description</td>";
                            echo "<td><img src='uploads/$image' alt='$name'></td>";
                            echo "<td>
                                    <a href='editproduct.php?id=$id' class='button'>Edit</a> |
                                    <a href='deleteproduct.php?id=$id' class='button delete'>Delete</a>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='12'>No products found</td></tr>";
                    }

                    ?>
                </table>
            </section>
        </main>
    </div>

</body>

</html>
