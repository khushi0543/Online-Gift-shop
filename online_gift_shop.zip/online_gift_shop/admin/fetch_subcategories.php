<?php
require 'db.php'; // Include your database connection

if (isset($_POST['category_id'])) {
    $categoryId = $_POST['category_id'];
    $sql = "SELECT id, subcategoryname FROM subcategory WHERE category_id = '$categoryId'";
    $result = $conn->query($sql);
    
    $options = '<option value="">Select Subcategory</option>'; // Default option
    while ($row = $result->fetch_assoc()) {
        $options .= '<option value="' . $row['id'] . '">' . htmlspecialchars($row['subcategoryname']) . '</option>';
    }
    echo $options; // Output the options
}
?>
