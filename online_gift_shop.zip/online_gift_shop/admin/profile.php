<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php';

require 'db.php'; // Ensure this file has $conn initialized

error_reporting(E_ALL);
ini_set('display_errors', 1);

$email = $_SESSION['a_email'];

// Fetch admin profile data
$query = "SELECT * FROM admin WHERE email = '$email'";
$result = mysqli_query($conn, $query);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);
    } else {
        $error = "No profile information found.";
    }
} else {
    $error = "Error fetching profile data: " . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Global Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            font-size: 28px;
            color: #333;
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .profile-info label {
            font-weight: bold;
        }

        .profile-info p {
            margin: 0;
            color: #333;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }

        .message.error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Profile</h1>
        <div class="profile-info">
            <?php if (isset($admin)) { ?>
                <p><label for="fname">First Name:</label> <span><?php echo $admin['fname']; ?></span></p>
                <p><label for="lname">Last Name:</label> <span><?php echo $admin['lname']; ?></span></p>
                <p><label for="gender">Gender:</label> <span><?php echo $admin['gender']; ?></span></p>
                <p><label for="email">Email:</label> <span><?php echo $admin['email']; ?></span></p>
                <p><label for="contact">Contact:</label> <span><?php echo $admin['contact']; ?></span></p>
                <p><label for="address">Address:</label> <span><?php echo $admin['address']; ?></span></p>
                <p><label for="lastLogin">Last Login:</label> <span><?php echo $admin['lastLogin']; ?></span></p>
            <?php } else if (isset($error)) { ?>
                <p class="message error"><?php echo $error; ?></p>
            <?php } ?>
            <a href="logout.php" class="btn">Logout</a>
        </div>
    </div>
</body>
</html>
