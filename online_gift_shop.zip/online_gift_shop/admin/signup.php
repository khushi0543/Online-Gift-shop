        <?php
        include 'top.php';
        ob_start();
        session_start(); // Make sure session is started
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Overall body styling */
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #e9ecef;
            margin: 0;
        }

        /* Form container styling */
        .registration_form {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        /* Form title styling */
        .registration_form h3 {
            text-align: center;
            font-weight: 700;
            margin-bottom: 30px;
            color: #343a40;
        }

        /* Form input styling */
        .form-label {
            font-weight: 600;
            color: #495057;
        }

        .form-control {
            border-radius: 6px;
            border: 1px solid #ced4da;
            box-shadow: none;
            transition: border-color 0.3s ease-in-out;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        /* Styling for the submit button */
        .btn-submit {
            background-color: #007bff;
            color: #fff;
            padding: 12px;
            border-radius: 6px;
            width: 100%;
            font-weight: bold;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        /* Custom styling for input groups */
        .input-group {
            margin-bottom: 20px;
        }

        /* Address textarea styling */
        textarea {
            resize: none;
        }

        /* Mobile responsiveness */
        @media screen and (max-width: 768px) {
            .registration_form {
                padding: 30px;
                width: 90%;
            }
        }

        @media screen and (max-width: 576px) {
            .registration_form {
                padding: 20px;
            }

            h3 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>

    <div class="registration_form">
        <h3>User Registration</h3>
        <form action="#" method="POST">

            <!-- User ID and First Name in a row -->
            <div class="row">
                
                <div class="col-md-6 input-group">
                    <label for="fname" class="form-label">First Name</label>
                    <input type="text" id="fname" name="fname" class="form-control" placeholder="Enter your first name" required>
                </div>
            </div>

            <!-- Last Name and Gender in a row -->
            <div class="row">
                <div class="col-md-6 input-group">
                    <label for="lname" class="form-label">Last Name</label>
                    <input type="text" id="lname" name="lname" class="form-control" placeholder="Enter your last name" required>
                </div>
                <div class="col-md-6 input-group">
                    <label for="gender" class="form-label">Gender</label>
                    <select id="gender" name="gender" class="form-control" required>
                        <option value="">Select your gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>

            <!-- Email and Password in a row -->
            <div class="row">
                <div class="col-md-6 input-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
                <div class="col-md-6 input-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
            </div>

            <!-- Contact Number -->
            <div class="input-group">
                <label for="contact" class="form-label">Contact Number</label>
                <input type="tel" id="contact" name="contact" class="form-control" placeholder="Enter your contact number" required>
            </div>

            <!-- Address -->
            <div class="input-group">
                <label for="address" class="form-label">Address</label>
                <textarea id="address" name="address" class="form-control" rows="3" placeholder="Enter your address"></textarea>
            </div>

            <!-- Last Login (Hidden Field) -->
            <input type="hidden" name="lastLogin" value="<?php echo date('Y-m-d H:i:s'); ?>">

            <!-- Submit Button -->
            <button type="submit" class="btn-submit" name="register">Register</button>

        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>


        <?php
        if (isset($_POST['register'])) {
            // Get form data
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $gender = $_POST['gender'];
            $eid = $_POST['email'];
            $password = $_POST['password'];
            $contact = $_POST['contact'];
            $address = $_POST['address'];
            $lastLogin = $_POST['lastLogin'];

            // Establish database connection (replace 'db.php' with your database connection details)
            require 'db.php';

            // Insert query (Add columns explicitly and pass all values)
            $q = "INSERT INTO admin VALUES (null, '$fname', '$lname', '$gender', '$eid', '$password', '$contact', '$address', '$lastLogin')";

            // Execute the query
            if (mysqli_query($conn, $q)) {
            // Store user ID in session and redirect to home page
            $eid = mysqli_insert_id($conn);

            // Store user ID and name in session variables
            $_SESSION['a_email'] = $eid;
            $_SESSION['admin_name'] = $fname;
    
            header("Location: index.php");

        } else {
            // Display error message if insertion fails
            echo "Error: " . mysqli_error($conn);
        }
        }
        ?>