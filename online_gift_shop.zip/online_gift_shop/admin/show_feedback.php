<?php
session_start();
require 'db.php'; // Include your database connection file
include 'slidebar.php';
// Fetch all feedback records from the database
$query = "SELECT * FROM feedback ORDER BY created_at DESC";
$result = $conn->query($query);

if (!$result) {
    die("Error fetching feedback: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
        body {
            background-color: #f8f9fa; /* Light background for better contrast */
        }
        .table {
            background-color: #ffffff; /* White background for the table */
            color: #333; /* Dark text color for readability */
        }
        .table th {
            background-color: #fff; /* Blue header */
            color: #000; /* White text for the header */
        }
        .table th, .table td {
            vertical-align: middle; /* Center align cells */
        }
        h2{
            color: #fff;
          margin-left: 288px;
        }
    </style>
</head>
<body>
    <h2>Manage FeedBack</h2>
<div class="container mt-5">
    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['message']); ?></td>
                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No feedback available.</p>
    <?php endif; ?>

</div>
</body>
</html>

<?php
$conn->close();
?>
