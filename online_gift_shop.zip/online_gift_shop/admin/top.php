<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Online Gift Shop Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link href="..\bs\css\bootstrap.min.css" rel="stylesheet">

</head>
<style>
  body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
  }

  nav {
    background: #7D8035;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 99;
  }

  .navbar {
    align-items: center;
    display: flex;
    justify-content: space-between;
    margin: auto;
    max-width: 1250px;
    padding: 0 15px;
  }

  .logo img {
    width: 50px;
    /* Adjust width as per your logo size */
    height: 50px;
    /* Adjust height as per your logo size */
    margin-right: 10px;
    /* Space between logo image and text */
    border-radius: 50%;
    /* Makes the image round if the logo is square */
  }

  .logo a {
    color: #fff;
    font-size: 30px;
    font-weight: 600;
    text-decoration: none;
  }

  .nav-links {
    display: flex;
    align-items: center;
  }

  .links {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .links li {
    position: relative;
    margin-right: 20px;
  }

  .links li a {
    color: #fff;
    font-size: 15px;
    font-weight: 500;
    text-decoration: none;
    white-space: nowrap;
  }

  .links li:hover .htmlcss-arrow,
  .links li:hover .js-arrow {
    transform: rotate(180deg);
  }

  .sub-menu {
    background: #3E8DA8;
    border-radius: 0 0 4px 4px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    display: none;
    line-height: 40px;
    position: absolute;
    top: 100%;
    transition: all 0.3s ease;
    z-index: 2;
  }

  .links li:hover .htmlCss-sub-menu,
  .links li:hover .js-sub-menu {
    display: block;
  }

  .sub-menu li {
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    padding: 10px 15px;
  }

  .sub-menu a {
    color: #fff;
    font-size: 15px;
    font-weight: 500;
    text-decoration: none;
  }

  .buttons a {
    border-radius: 0.375rem;
    color: #fff;
    font-weight: 600;
    padding: 12px 24px;
    text-decoration: none;
    transition: 0.2s ease;
  }

  @media (max-width: 992px) {
    .navbar .logo a {
      font-size: 25px;
    }

    .links li {
      margin-right: 15px;
    }

    .links li a {
      font-size: 14px;
    }
  }
</style>

<body>
  <nav>
    <div class="navbar">
      <div class="logo"><a href="#">
          <img src="/gift_photo/logo.jpg">
          Online Gift Shop
        </a></div>
      <div class="nav-links">
        <ul class="links">
          <li><a href="#">Dashboard</a></li>
          <li>
            <a href="#">Product Management</a>
            <i class='bx bxs-chevron-down htmlcss-arrow'></i>
            <ul class="htmlCss-sub-menu sub-menu">
              <li><a href="category.php">Category</a></li>
              <li><a href="subcategory.php">Subcategory</a></li>
              <li><a href="manage_product.php">Product</a></li>
              <li><a href="brand.php">Brand</a></li>
              <li><a href="order.php"> view Order</a></li>
            </ul>
          </li>
          <li><a href="aboutas.php">About Us</a></li>
          <li><a href="#">Contact Us</a></li>
          <li><a href="viewadmin.php"> View Admin</a></li>
        </ul>
      </div>
      <div class="buttons">
        <!-- <a href="index.php" class="signin">Sign In</a>
        <a href="signup.php" class="signup">Sign Up</a> -->
        <a href="logout.php" class="signup">logout</a>
      </div>
    </div>
  </nav>
  <!-- Bootstrap JS -->
  <script src="jquery-3.4.1.js"></script>
  <script src="..bs/js/bootstrap.min.js"></script>
</body>

</html>