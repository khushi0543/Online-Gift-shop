<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
include 'slidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subcategory</title>
    <link rel="stylesheet" href="../bs/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="../bs/sweetalert.js"></script>
    <style>
          body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .content {
            margin-left: 270px;
            padding: 0;
            flex: 1;
        }

        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
        }

        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .header-buttons.left {
            left: 20px;
        }

        .header-buttons.right {
            right: 20px;
        }

        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .header-buttons a:hover {
            background-color: #333;
        }

        main {
            padding: 20px;
        }

        .search-bar {
            margin-bottom: 20px;
        }

        #search-input {
            width: 50%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .subcategory-table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid gray;
            background-color: #f4f4f4;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .subcategory-table th, .subcategory-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #000;
        }

        .subcategory-table th {
            background-color: #fff;
            color: #000;
        }

        .subcategory-table td a {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: background-color 0.3s ease;
        }

        .subcategory-table td a i {
            margin-right: 5px;
        }

        .subcategory-table td a:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
        }

        .message.success {
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
    <script>
        $(document).ready(function() {
            $("#search-input").on("input", function() {
                var query = $(this).val();

                $.ajax({
                    url: 'searchsubcategory.php',
                    method: 'POST',
                    data: { query: query },
                    success: function(response) {
                        $("#result").html(response);
                    },
                    error: function() {
                        alert("An error occurred.");
                    }
                });
            });
        });
    </script>
</head>
<body>

<div class="content">
    <header>
        <h1>Manage Subcategory</h1>
        <div class="header-buttons">
            <a href="addsubcategory.php" class="button add">Add Subcategory</a>
        </div>
    </header>

    <div class="search-bar">
        <input type="text" id="search-input" placeholder="Search subcategories..." />
    </div>

    <div id="result">
        <?php
        require 'db.php';

        // Query to select all subcategories with their categories
        $q = "SELECT subcategory.id, subcategory.subcategoryname, category.categoryname 
              FROM subcategory 
              JOIN category ON subcategory.categoryid = category.id";
        $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
        $nor = mysqli_num_rows($res);

        // If there are rows, display them in a table
        if ($nor > 0) {
            echo "<table class='subcategory-table'>";
            echo "<tr>
                    <th>Subcategory ID</th>
                    <th>Subcategory Name</th>
                    <th>Category Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";

            // Fetch each row and display it
            while ($r = mysqli_fetch_assoc($res)) {
                echo "<tr>
                        <td>{$r['id']}</td>
                        <td>{$r['subcategoryname']}</td>
                        <td>{$r['categoryname']}</td>
                        <td><a href='editsubcategory.php?subcategoryid={$r['id']}' class='button edit'><i class='fas fa-edit'></i> Edit</a></td>
                        <td><a href='deletesubcategory.php?subcategoryid={$r['id']}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='message'>No subcategories found.</p>";
        }

        // Display messages if present
        if (isset($_REQUEST['imsg'])) {
            echo "<div class='message success'>" . htmlspecialchars($_REQUEST['imsg']) . "</div>";
             echo '<div class="alert m-2 alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
            <h5><i class="icon fas fa-check"></i> Success!</h5>
            Data inserted successfully!
            </div>';
        }
        if (isset($_REQUEST['umsg'])) {
            echo "<div class='message error'>" . htmlspecialchars($_REQUEST['umsg']) . "</div>";
        }
        ?>
    </div>
</div>

</body>
</html>
