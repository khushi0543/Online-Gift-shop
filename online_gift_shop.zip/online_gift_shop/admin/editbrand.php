<?php
session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
?>
<html lang="en">

<head>
    <title>Edit Brand</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 10px;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>
<?php
require 'db.php';

// Check if the brand ID is set
if (isset($_GET['brandid'])) {
    $brandid = $_GET['brandid'];
    
    // Fetch the brand details
    $q = "SELECT * FROM brand WHERE id = '$brandid'";
    $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
    $brand = mysqli_fetch_array($res);
    
    // If the form is submitted, update the brand details
    if (isset($_POST['update'])) {
        $brandname = $_POST['brandname'];
        
        // Update query
        $q = "UPDATE brand SET brandname = '$brandname' WHERE id = '$brandid'";
        if (mysqli_query($conn, $q)) {
            // Redirect with success message
            header("Location: brand.php?umsg=brand updated successfully!");
        } else {
            echo "Update Failed: " . mysqli_error($conn);
        }
    }
} else {
    die("No color ID provided!");
}
?>

<body>

<div class="container">
    <h2>Edit Brand</h2>
    <form method="POST">
        <label for="brandname">Brand Name:</label>
        <input type="text" name="brandname" value="<?php echo $brand['brandname']; ?>" required>
        
        <input type="submit" name="update" value="Update">
    </form>

    <!-- Back to the brand list page -->
    <a href="brand.php" class="back-link">Back to Brand List</a>
</div>

</body>
</html>
