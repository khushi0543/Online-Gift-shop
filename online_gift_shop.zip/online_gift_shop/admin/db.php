

<?php 
$conn=mysqli_connect("localhost","root","","onlinegiftshop")or die("Database Not Found");

?>
