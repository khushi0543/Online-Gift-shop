<?php
require 'db.php'; 

if (isset($_REQUEST['delsubcategoryid'])) {
    $subcategoryid = intval($_REQUEST['delsubcategoryid']);

    $sql = "DELETE FROM subcategory WHERE id = $subcategoryid";

    if (mysqli_query($conn, $sql)) {
        header('Location: subcategory.php?imsg=Subcategory+deleted+successfully.');
        
    } else {
        header('Location: subcategory.php?umsg=Error+deleting+subcategory.');
    
    }
} else {
    header('Location: subcategory.php?umsg=No+subcategory+ID+provided.');
    
}

?>
