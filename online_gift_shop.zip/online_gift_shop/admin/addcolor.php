<?php
session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
?>
<html lang="en">

<head>
    <title>Add Color</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
        }

        td {
            padding: 10px;
        }

        input[type="text"] {
            padding: 10px;
            width: 100%;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Add Color</h2>
    <form action="" method="post">
        <table align="center" cellspacing="10" cellpadding="10" border="0">
            <tr>
                <td>Color Name</td>
                <td><input type="text" name="colorname" required></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" value="Insert" name="insert">
                </td>
            </tr>
        </table>
    </form>
</div>
</body>
<?php
if (isset($_REQUEST['insert'])) {
    $colorname = $_REQUEST['colorname'];
    require 'db.php';
    $q = "INSERT INTO color VALUES (NULL, '$colorname')";
    if (mysqli_query($conn, $q))
        header("Location: color.php?imsg=Color Added");
    else
        die("Query Failed!!!" . mysqli_error($conn));
}
?>
