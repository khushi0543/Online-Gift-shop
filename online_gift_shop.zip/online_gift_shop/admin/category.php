<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    echo "<script>window.location='index.php';</script>";
    
    exit();
}
include 'slidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Category</title>
    <link rel="stylesheet" href="../bs/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="../bs/sweetalert.js"></script>

<link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
     
                body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .content {
            margin-left: 270px;
            padding: 0;
            flex: 1;
        }

        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
        }

        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .header-buttons.left {
            left: 20px;
        }

        .header-buttons.right {
            right: 20px;
        }

        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .header-buttons a:hover {
            background-color: #333;
        }


        .button.edit {
            background-color: #007bff;
        }

        .button.delete {
            background-color: #dc3545;
        }

        .search-bar {
            margin-bottom: 20px;

        }

        #search-input {
            width: 50%;
            padding: 10px;
            margin-left: 580px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        main {
            padding: 20px;
        }

        .category-table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid gray;
            background-color: #f4f4f4;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .category-table th, .category-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #000;
        }

        .category-table th {
            background-color: #fff;
            color: #000;
        }

        .category-table td a {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: background-color 0.3s ease;
        }

        .category-table td a i {
            margin-right: 5px;
        }

        .category-table td a:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
        }

        .message.success {
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
    <script>
        $(document).ready(function() {
            $("#search-input").on("input", function() {
                var query = $(this).val();

                $.ajax({
                    url: 'searchcategory.php',
                    method: 'POST',
                    data: { query: query },
                    success: function(response) {
                        $(".result").html(response);
                    },
                    error: function() {
                        alert("An error occurred.");
                    }
                });
            });
        });
    </script>
</head>
<body>

<div class="content">

    <header>
    <a href="javascript:history.back()" class="header-buttons left"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
                <h1>Manage Category</h1>
            <div class="header-buttons right">
            <a href="addcategory.php" class="button">Add Category</a>
            </div>
        </header>


    <div class="search-bar">
        <input type="text" id="search-input" placeholder="Search categories..." />
    </div>

  <main class="result">       
     <?php
        require 'db.php';

        // Query to select all rows from category
        $q = "SELECT * FROM category";
        $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
        $nor = mysqli_num_rows($res);

        // If there are rows, display them in a table
        if ($nor > 0) {
            echo "<table class='category-table'>";
            echo "<tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";

            // Fetch each row and display it
            while ($r = mysqli_fetch_array($res)) {
                echo "<tr>
                        <td>{$r[0]}</td>
                        <td>{$r[1]}</td>
                            <td><a href='editcategory.php?categoryid={$r[0]}' class='button edit'><i class='fas fa-edit'></i> Edit</a></td>
                            <td><a href='deletecategory.php?categoryid={$r[0]}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
                    </tr>";
            }
            echo "</table>";
        }

        // Display messages if present
        if (isset($_REQUEST['imsg'])) {
            echo "<div class='message success'>" . $_REQUEST['imsg'] . "</div>";
            echo '<div class="alert m-2 alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
            <h5><i class="icon fas fa-check"></i> Success!</h5>
            Data inserted successfully!
            </div>';
        }
        if (isset($_REQUEST['umsg'])) {
            echo "<div class='message error'>" . $_REQUEST['umsg'] . "</div>";
        }
        ?>
   </main>

</div>

</body>
</html>
