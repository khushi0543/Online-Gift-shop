<?php
require 'db.php';

// Check if the brand ID is set
if (isset($_GET['colorid'])) {
    $colorid = $_GET['colorid'];
    
    // Delete query
    $q = "DELETE FROM color WHERE id = '$colorid'";
    print_r($q);
    if (mysqli_query($conn, $q)) {
        // Redirect with success message
        header("Location: color.php?imsg=Brand deleted successfully!");
    } else {
        echo "Deletion Failed: " . mysqli_error($conn);
    }
} else {
    die("No brand ID provided!");
}
?>
