<?php
require 'db.php';

// Retrieve and escape the search query
$query = isset($_POST['query']) ? mysqli_real_escape_string($conn, $_POST['query']) : '';

// Query to search subcategories based on the query
$sql = "SELECT subcategory.id, subcategory.subcategoryname, category.categoryname 
        FROM subcategory 
        JOIN category ON subcategory.categoryid = category.id
        WHERE subcategory.subcategoryname LIKE '%$query%' 
        OR category.categoryname LIKE '%$query%'";
$res = mysqli_query($conn, $sql) or die('Query Failed!!!' . mysqli_error($conn));
$nor = mysqli_num_rows($res);

// If there are rows, display them in a table
if ($nor > 0) {
    echo "<table class='subcategory-table'>";
    echo "<tr>
            <th>Subcategory ID</th>
            <th>Subcategory Name</th>
            <th>Category Name</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>";

    // Fetch each row and display it
    while ($row = mysqli_fetch_array($res)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['subcategoryname']}</td>
                <td>{$row['categoryname']}</td>
                <td><a href='editsubcategory.php?subcategoryid={$row['id']}' class='button edit'><i class='fas fa-edit'></i> Edit</a></td>
                <td><a href='deletesubcategory.php?subcategoryid={$row['id']}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
            </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No subcategories found.</p>";
}

$conn->close();
?>
