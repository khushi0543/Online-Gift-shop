<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

require 'db.php';

if (isset($_GET['colorid'])) {
    $colorid = $_GET['colorid'];
    $q = "SELECT * FROM color WHERE id = '$colorid'";
    $res = mysqli_query($conn, $q) or die(mysqli_error($conn));
    $color = mysqli_fetch_array($res);
    
    if (isset($_POST['update'])) {
        $colorname = $_POST['colorname'];
        $q = "UPDATE color SET colorname = '$colorname' WHERE id = '$colorid'";
        if (mysqli_query($conn, $q)) {
            header("Location: color.php?umsg=color updated successfully!");
        } else {
            echo "Update Failed: " . mysqli_error($conn);
        }
    }
} else {
    die("No color ID provided!");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit Color</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 10px;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Edit Color</h2>
    <form method="POST">
        <label for="colorname">Color Name:</label>
        <input type="text" name="colorname" value="<?php echo $color['colorname']; ?>" required>
        <input type="submit" name="update" value="Update">
    </form>
    <a href="color.php" class="back-link">Back to Color List</a>
</div>
</body>
</html>
