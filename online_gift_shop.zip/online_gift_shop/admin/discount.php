<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

require 'db.php';  // Include your database connection

// Add new discount
if (isset($_POST['add_discount'])) {
    $discount_name = $_POST['discount_name'];
    $discount_percentage = $_POST['discount_percentage'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $status = $_POST['status'];

    // Insert new discount into the database
    $query = "INSERT INTO discounts (discount_name, discount_percentage, start_date, end_date, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sdsis', $discount_name, $discount_percentage, $start_date, $end_date, $status);

    if ($stmt->execute()) {
        $message = "Discount added successfully.";
    } else {
        $message = "Error adding discount: " . $conn->error;
    }
}

// Fetch existing discounts
$query = "SELECT * FROM discounts";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Manage Discounts</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Discounts</h1>

        <?php if (isset($message)) echo "<p class='message'>{$message}</p>"; ?>

        <!-- Form to add a new discount -->
        <form method="POST">
            <h2>Add New Discount</h2>
            <label for="discount_name">Discount Name:</label>
            <input type="text" id="discount_name" name="discount_name" required>
            
            <label for="discount_percentage">Discount Percentage:</label>
            <input type="number" step="0.01" id="discount_percentage" name="discount_percentage" required>

            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>

            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>

            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>

            <button type="submit" name="add_discount">Add Discount</button>
        </form>

        <!-- Display existing discounts -->
        <h2>Existing Discounts</h2>
        <table class='discount-table'>
            <tr>
                <th>Discount ID</th>
                <th>Discount Name</th>
                <th>Discount Percentage</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['discount_id']}</td>
                        <td>{$row['discount_name']}</td>
                        <td>{$row['discount_percentage']}%</td>
                        <td>{$row['start_date']}</td>
                        <td>{$row['end_date']}</td>
                        <td>{$row['status']}</td>
                        <td>
                            <a href='edit_discount.php?id={$row['discount_id']}'>Edit</a>
                            <a href='delete_discount.php?id={$row['discount_id']}'>Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No discounts found.</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
