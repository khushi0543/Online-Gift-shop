<?php
// Include the database connection file
require 'db.php';

// Start session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - View Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .container {
            margin-top: 50px;
        }
        h2 {
            color: #343a40; /* Ensure visible heading color */
            margin-bottom: 20px; /* Add space below heading */
            font-weight: bold;
            text-align: center;
        }
        table {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

<!-- Container to ensure the page is centered properly -->
<div class="container">
    <!-- Heading for the page -->
    <h2 class="text-center">Registered Users</h2>

    <!-- Table to display user data -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>User ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Last Login</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Fetch the user records from the 'user_register' table
        $sql = "SELECT * FROM admin";
        $result = mysqli_query($conn, $sql);

        // Check if there are any users
        if (mysqli_num_rows($result) > 0) {
            // Loop through each user and display their data in the table
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$row['userid']}</td>
                        <td>{$row['fname']}</td>
                        <td>{$row['lname']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['contact']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['lastLogin']}</td>
                    </tr>";
            }
        } else {
            // If no users found, display a message
            echo "<tr><td colspan='8'>No users found</td></tr>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
