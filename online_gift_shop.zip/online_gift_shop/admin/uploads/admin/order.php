<?php 

session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php'; // Include your sidebar or navigation if needed
require 'db.php'; // Include your database connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            background-color: #ecf0f5;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 24px;
            margin: 0;
            color: #333;
        }

        .order-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .order-table th, .order-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .order-table th {
            background-color: #f8f8f8;
            color: #333;
            text-transform: uppercase;
        }

        .order-table td a {
            color: #007bff;
            text-decoration: none;
        }

        .order-table td a:hover {
            color: #0056b3;
        }

        .button {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #333;
        }

        .button.delete {
            background-color: #d9534f;
        }

        .button.delete:hover {
            background-color: #c9302c;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>Manage Orders</h1>
        </header>
        <br><br><br>

        <?php
        // Correct query based on actual column names
        $q = "SELECT orders.order_id, product.name AS product_name, product.regularprice AS price, product.category_id, orders.order_date, orders.quantity, orders.total_price
              FROM orders
              JOIN product ON orders.product_id = product.productid";
        $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
        $nor = mysqli_num_rows($res);

        // If there are orders, display them in a table
        if ($nor > 0) {
            echo "<table class='order-table'>";
            echo "<tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Order Date</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Actions</th>
                </tr>";

            // Fetch each order and display it
            while ($r = mysqli_fetch_assoc($res)) {
                // Fetch category name based on category_id
                $category_query = "SELECT name FROM category WHERE id = {$r['category_id']}";
                $category_res = mysqli_query($conn, $category_query);
                $category_name = mysqli_fetch_assoc($category_res)['name'];

                echo "<tr>
                        <td>{$r['order_id']}</td>
                        <td>{$r['product_name']}</td>
                        <td>{$r['price']}</td>
                        <td>{$category_name}</td>
                        <td>{$r['order_date']}</td>
                        <td>{$r['quantity']}</td>
                        <td>{$r['total_price']}</td>
                        <td><a href='deleteorder.php?orderid={$r['order_id']}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='message'>No orders found.</p>";
        }

        // Display messages if present
        if (isset($_REQUEST['msg'])) {
            echo "<div class='message'>" . $_REQUEST['msg'] . "</div>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
