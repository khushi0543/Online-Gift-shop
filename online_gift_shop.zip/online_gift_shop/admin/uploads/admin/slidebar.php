<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Gift Shop</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="../bs/sweetalert.js"></script>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #fff;
            color: #fff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('images/back.jpg');
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        a {
            color: #fff;
            text-decoration: none;
        }

        a:hover {
            color: #ccc;
        }

        .header {
            background-color: #111;
            color: #fff;
            padding: 15px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
        }

        .header .logo img {
            height: 40px;
        }

        .header .site-title {
            font-size: 24px;
            font-weight: bold;
        }

        .header .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header .user-info a {
            color: #ccc;
        }

        .header .user-info a:hover {
            color: #fff;
        }

        .main-sidebar {
            background-color: #111;
            color: #fff;
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 60px;
            left: 0;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .main-sidebar.collapsed {
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }

        .main-sidebar.active {
            transform: translateX(0);
        }

        .user-panel {
            background-color: #222;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .user-panel .image img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        .user-panel .info {
            color: #fff;
            padding-left: 10px;
        }

        .user-panel .info a {
            color: #ccc;
        }

        .user-panel .info a:hover {
            color: #fff;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin-bottom: 10px;
        }

        .sidebar-menu .header {
            color: #777;
            font-size: 14px;
            padding: 10px 0;
            text-transform: uppercase;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 10px;
            color: #ccc;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .sidebar-menu a:hover {
            background-color: #333;
            color: #fff;
        }

        .sidebar-menu i {
            margin-right: 10px;
            color: #bbb;
        }

        .footer {
            background-color: #111;
            color: #fff;
            text-align: center;
            padding: 15px 0;
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.5);
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            margin-top: 80px;
        }

        @media (max-width: 768px) {
            .main-sidebar {
                transform: translateX(-100%);
                position: fixed;
            }

            .main-sidebar.active {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
            }

            .header {
                left: 0;
            }

            .footer {
                left: 0;
            }
        }

        .toggle-sidebar {
            font-size: 24px;
            cursor: pointer;
            display: none;
        }

        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                z-index: 1001;
                color: #fff;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="header">

        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <div class="site-title">
            Online Gift Shop
        </div>
        <div class="user-info" style="padding-right: 50px;">
            <a href="profile.php"><i class="fa fa-user"></i> Profile</a>
            <a href="index.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Sign In</a>
        </div>
    </header>

    <!-- Sidebar -->
    <div class="main-sidebar">
        <aside class="sidebar">
            <div class="user-panel">
                <div class="image">
                    <img src="images/logo.jpg" class="img-circle" alt="Admin Image">
                </div>
                <div class="info">
                    <a href="#"><i class="fa fa-circle text-success"></i> Online Gift Shop</a>
                </div>
            </div>
            <ul class="sidebar-menu" data-widget="tree">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="category.php"><i class="fa fa-list-alt"></i> Manage Categories</a></li>
                <li><a href="subcategory.php"><i class="fa fa-list"></i> Manage Subcategories</a></li>
                <li><a href="brand.php"><i class="fa fa-briefcase"></i> Manage Brands</a></li>
                <li><a href="manage_product.php"><i class="fa fa-shopping-cart"></i> Manage Products</a></li>
                <ul>
                    <li>
                        <a href="color.php">color</a>
                    </li>
                </ul>
                <li><a href="order.php"><i class="fas fa-jedi-order"></i> Manage Orders</a></li>
                <li><a href="manage_discounts.php"><i class="fa fa-percent"></i> Manage Discounts</a></li>
                <li><a href="manage_subscribers.php"><i class="fa fa-subscript"></i> Manage Subscribers</a></li>
                <li><a href="manage_user.php"><i class="fa fa-users"></i> View Customers</a></li>
                <li><a href="view_feedback.php"><i class="fa fa-comments"></i> View Feedback</a></li>
                <li><a href="report.php"><i class="fa fa-bar-chart"></i> Reports</a></li>
                <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
            </ul>
        </aside>
    </div>

    <!-- Main content area -->
    <div class="content">
        <!-- Content will be included here -->
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 Online Gift Shop. All rights reserved.</p>
    </footer>

    <script>
        const toggleSidebar = document.querySelector('.toggle-sidebar');
        const sidebar = document.querySelector('.main-sidebar');

        toggleSidebar.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    </script>

</body>

</html>
