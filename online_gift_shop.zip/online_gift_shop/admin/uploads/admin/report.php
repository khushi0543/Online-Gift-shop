<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php';
require 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reports</title>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 20px;
            color: white;
        }
        .report-table {
            margin-top: 20px;
           background-color: black;
           color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Reports</h1>
        <div class="row">
            <div class="col-md-6">
                <h2>Sales Report</h2>
                <table class="table table-bordered report-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Order Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $salesQuery = "SELECT o.order_id, p.name AS product_name, od.quantity, (od.quantity * p.saleprice) AS total_price, o.order_date
                                       FROM orders o
                                       JOIN order_details od ON o.order_id = od.order_id
                                       JOIN product p ON od.product_id = p.productid";
                        $salesResult = mysqli_query($conn, $salesQuery);

                        if ($salesResult->num_rows > 0) {
                            while ($row = $salesResult->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>{$row['order_id']}</td>";
                                echo "<td>{$row['product_name']}</td>";
                                echo "<td>{$row['quantity']}</td>";
                                echo "<td>{$row['total_price']}</td>";
                                echo "<td>{$row['order_date']}</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>No sales data found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-6">
                <h2>Inventory Report</h2>
                <table class="table table-bordered report-table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Brand</th>
                            <th>Category</th>
                            <th>Subcategory</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Quantity</th>
                            <th>Regular Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $inventoryQuery = "SELECT p.name AS product_name, b.brandname, c.categoryname, sub.subcategoryname, co.colorname, s.sizename, p.qty, p.regularprice
                                           FROM product p
                                           LEFT JOIN brand b ON p.brand_id = b.id
                                           LEFT JOIN category c ON p.category_id = c.id
                                           LEFT JOIN size s ON p.size_id = s.id
                                           LEFT JOIN color co ON p.color_id = co.id
                                           LEFT JOIN subcategory sub ON p.subcategory_id = sub.id";
                        $inventoryResult = mysqli_query($conn, $inventoryQuery);

                        if ($inventoryResult->num_rows > 0) {
                            while ($row = $inventoryResult->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>{$row['product_name']}</td>";
                                echo "<td>{$row['brandname']}</td>";
                                echo "<td>{$row['categoryname']}</td>";
                                echo "<td>{$row['subcategoryname']}</td>";
                                echo "<td>{$row['colorname']}</td>";
                                echo "<td>{$row['sizename']}</td>";
                                echo "<td>{$row['qty']}</td>";
                                echo "<td>{$row['regularprice']}</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No inventory data found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
