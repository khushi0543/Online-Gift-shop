<?php require("../connect.php"); ?>
<?php session_start(); ?>
<link rel="stylesheet" href="../bs/css/bootstrap.css" />
<style>
  .t2 {
    font-size: 20px;

    color: #262187;
  }

  .t1 {
    font-size: 20px;
    border-radius: 10px;
    color: #262187;
  }

  select {
    border-radius: 10px;
  }

  input {
    border-radius: 10px;
    color: #FFFFFF;
  }

  .btn1 {
    background: linear-gradient(to bottom right, #000099, #CFDCFE);
    border-radius: 10px;
    width: 100px;
    height: 40px;
    color: #FFFFFF;
  }
</style>
<table width='1000' align='center' class='t2' bgcolor='#C0DBFE' cellpadding='5px' cellspacing='5px'>
  <tr>
    <td><?php require("top.php"); ?></td>
  </tr>
  <tr>
    <td>
      <?php
      $q = "select * from feedback";
      $res = mysqli_query($con, $q);
      $nor = mysqli_num_rows($res);
      if ($nor > 0) {
        echo "<table  width='500' align='center' class='t1' bgcolor='#BBC5F9'>
";
        echo "<tr>
<th>EmailID</th>
<th>FeedBack</th>
</tr>";
        while ($r = mysqli_fetch_array($res)) {
          echo "<tr>
<td>$r[1]</td>
<td>$r[2]</td>
</tr>";
        }
        echo "</table>";
      } else {
        echo "NO feedBack Found";
      }
      ?>
    </td>
  </tr>
  <tr>
    <?php require("bottom.php"); ?>
    <td>
    </td>
  </tr>
</table>