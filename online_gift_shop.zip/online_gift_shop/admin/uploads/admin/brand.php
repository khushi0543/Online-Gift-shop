<?php
session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

include 'slidebar.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Brands</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .content {
            margin-left: 270px;
            padding: 0;
            flex: 1;
        }

        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
        }

        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .header-buttons.left {
            left: 20px;
        }

        .header-buttons.right {
            right: 20px;
        }

        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .header-buttons a:hover {
            background-color: #333;
        }

        main {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 2px solid gray;
            background-color: #f4f4f4;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            color: #000;
        }

        th {
            background-color: #fff;
            color: #000;
            text-transform: uppercase;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        .button {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .button.delete {
            background-color: #e74c3c;
        }

        .button:hover {
            background-color: #333;
        }

        .button.delete:hover {
            background-color: #c9302c;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
</head>

<body>
    <div class="content">
        <header>
            <a href="javascript:history.back()" class="header-buttons left"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
            <h1>Manage Brands</h1>
            <div class="header-buttons right">
                <a href="addbrand.php" class="button">Add Brand</a>
            </div>
        </header>

        <main>
            <?php
            require 'db.php';

            $q = "SELECT * FROM brand";
            $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
            $nor = mysqli_num_rows($res);

            if ($nor > 0) {
                echo "<table class='brand-table'>";
                echo "<tr>
                        <th>Brand ID</th>
                        <th>Brand Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>";

                while ($r = mysqli_fetch_assoc($res)) {
                    echo "<tr>
                            <td>{$r['id']}</td>
                            <td>{$r['brandname']}</td>
                            <td><a href='editbrand.php?brandid={$r['id']}' class='button'><i class='fas fa-edit'></i> Edit</a></td>
                            <td><a href='deletebrand.php?brandid={$r['id']}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='message'>No brands found.</p>";
            }

            if (isset($_REQUEST['imsg'])) {
                echo "<div class='message'>" . $_REQUEST['imsg'] . "</div>";
            }
            if (isset($_REQUEST['umsg'])) {
                echo "<div class='message error'>" . $_REQUEST['umsg'] . "</div>";
            }


            mysqli_close($conn);
            ?>
        </main>
    </div>
</body>

</html>