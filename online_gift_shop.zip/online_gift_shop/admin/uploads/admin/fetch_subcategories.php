<?php
require 'db.php';

if (isset($_POST['category_id'])) {
    $category_id = $_POST['category_id'];

    // Correct the query to use 'categoryid' instead of 'id'
    $sql = "SELECT id, subcategoryname FROM subcategory WHERE categoryid = '$category_id'";
    $result = $conn->query($sql);

    echo "<option value=''>Select Subcategory</option>";
    while ($row = $result->fetch_assoc()) {
        echo "<option value='" . $row['id'] . "'>" . $row['subcategoryname'] . "</option>";
    }
}
?>
