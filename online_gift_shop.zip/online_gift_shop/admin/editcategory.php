<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
?>
<html lang="en">

<head>
    <title>Edit Category</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 10px;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>
<?php
require 'db.php';

if (isset($_GET['categoryid'])) {
    $categoryid = $_GET['categoryid'];

    $q = "SELECT * FROM category WHERE id = '$categoryid'";
    $res = mysqli_query($conn, $q) or die('Query Failed!!! ' . mysqli_error($conn));
    $category = mysqli_fetch_array($res);
    

    if (isset($_POST['update'])) {
        $categoryname = $_POST['categoryname'];
        
        // Update query
        $q = "UPDATE category SET categoryname = '$categoryname' WHERE id = '$categoryid '";
        if (mysqli_query($conn, $q)) {

            header("Location: category.php?umsg=Category updated successfully!");
        } else {
            echo "Update Failed: " . mysqli_error($conn);
        }
    }
} else {
    die("No category ID provided!");
}
?>

<body>

<div class="container">
    <h2>Edit Category</h2>
    <form method="POST">
        <label for="categoryname">Category Name:</label>
        <input type="text" name="categoryname" value="<?php echo $category['categoryname']; ?>" required>
        
        <input type="submit" name="update" value="Update">
    </form>

    <!-- Back to the category list page -->
    <a href="category.php" class="back-link">Back to Category List</a>
</div>

</body>
</html>
