<?php
require 'db.php';

$query = isset($_POST['query']) ? mysqli_real_escape_string($conn, $_POST['query']) : '';

// Query to search categories based on the query
$sql = "SELECT * FROM category WHERE categoryname LIKE '%$query%'";
$res = mysqli_query($conn, $sql) or die('Query Failed!!!' . mysqli_error($conn));
$nor = mysqli_num_rows($res);

// If there are rows, display them in a table
if ($nor > 0) {
    echo "<table class='category-table'>";
    echo "<tr>
            <th>Category ID</th>
            <th>Category Name</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>";

    // Fetch each row and display it
    while ($r = mysqli_fetch_array($res)) {
        echo "<tr>
                <td>{$r[0]}</td>
                <td>{$r[1]}</td>
                <td><a href='editcategory.php?categoryid={$r[0]}' class='button edit'><i class='fas fa-edit'></i> Edit</a></td>
                <td><a href='deletecategory.php?categoryid={$r[0]}' class='button delete'><i class='fas fa-trash'></i> Delete</a></td>
            </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No categories found.</p>";
}

?>
