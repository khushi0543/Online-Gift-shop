<?php
require 'db.php';

if (isset($_GET['categoryid'])) {
    $categoryid = $_GET['categoryid'];

    $q = "SELECT * FROM category WHERE id = '$categoryid'";
    $res = mysqli_query($conn, $q);

    if (mysqli_num_rows($res) > 0) {
        // Delete query
        $q = "DELETE FROM category WHERE id = '$categoryid'";

        if (mysqli_query($conn, $q)) {
            header("Location: category.php?imsg=Category deleted successfully!");
        } else {
            echo "Deletion Failed: " . mysqli_error($conn);
        }
    } else {
        header("Location: category.php?umsg=Category not found!");
    }
} else {
    // No category ID provided in the URL
    die("No category ID provided!");
}
?>
