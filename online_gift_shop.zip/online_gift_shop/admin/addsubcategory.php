<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
require 'db.php';

if (isset($_REQUEST['addsubcategory'])) {
    $categoryid = $_REQUEST['categoryid'];
    $subcategoryname = $_REQUEST['subcategoryname'];

    $q = "INSERT INTO subcategory (categoryid, subcategoryname) VALUES ('$categoryid', '$subcategoryname')";

    if (mysqli_query($conn, $q)) {
        header("Location: subcategory.php?imsg=Subcategory added successfully!");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Correct variable name
$q = "SELECT * FROM category";
$res_categories = mysqli_query($conn, $q);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Subcategory</title>

    <link href="~/bs/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            color: #555;
            margin-bottom: 10px;
        }

        input[type="text"], select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #000;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Subcategory</h2>
    <form method="POST">
        <label for="categoryid">Category:</label>
        <select name="categoryid" id="categoryid" required>
            <option value="">Select Category</option>
            <?php
            // Populate the dropdown with category options
            while ($row = mysqli_fetch_assoc($res_categories)) {
                echo "<option value='" . $row['id'] . "'>" . $row['categoryname'] . "</option>";
            }
            ?>
        </select>

        <label for="subcategoryname">Subcategory Name:</label>
        <input type="text" name="subcategoryname" id="subcategoryname" placeholder="Enter subcategory name" required>

        <input type="submit" name="addsubcategory" value="Add Subcategory">
    </form>
</div>

</body>
</html>
