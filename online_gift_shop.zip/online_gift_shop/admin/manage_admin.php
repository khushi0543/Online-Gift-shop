<!DOCTYPE html>
<html>

<head>
    <title>Manage Products</title>
    <style>
               body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #28a745;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        main {
            padding: 20px;
        }

        a {
            text-decoration: none;
            color: #28a745;
        }

        a:hover {
            color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #28a745;
            color: #fff;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        .button {
            background-color: #007bff;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            margin: 0 5px;
        }

        .button:hover {
            background-color: #0056b3;
        }

        .button.delete {
            background-color: #dc3545;
        }

        .button.delete:hover {
            background-color: #c82333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }
 </style>
</head>

<body>
    <a href="addproduct.php">Add product</a>
    <header>
        <h1>Manage Products</h1>
    </header>

    <main>
        <section>
            <h2>Product List</h2>
            <table>
                <tr>
                    <th>Product Name</th>
                    <th>Brand</th>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Color</th>
                    <th>Size</th>
                    <th>Quantity</th>
                    <th>Regular Price</th>
                    <th>Sale Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
                <?php
                require 'db.php';

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Query to get all products
                $sql = "SELECT * FROM product";
                $result = $conn->query($sql);

                // Check if any products are returned
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        $id = $row['productid'];
                        $name = $row['name'];
                        $brand = $row['brand_id']; // Replace with actual brand name if using join
                        $category = $row['category_id']; // Replace with actual category name if using join
                        $subcategory = $row['subcategory_id']; // Replace with actual subcategory name if using join
                        $color = $row['color_id']; // Replace with actual color name if using join
                        $size = $row['size_id']; // Replace with actual size name if using join
                        $quantity = $row['qty'];
                        $regular_price = $row['regularprice'];
                        $sale_price = $row['saleprice'];
                        $description = $row['description'];
                        $image = $row['image'];

                        echo "<tr>";
                        echo "<td>$name</td>";
                        echo "<td>$brand</td>";
                        echo "<td>$category</td>";
                        echo "<td>$subcategory</td>";
                        echo "<td>$color</td>";
                        echo "<td>$size</td>";
                        echo "<td>$quantity</td>";
                        echo "<td>$regular_price $</td>";
                        echo "<td>$sale_price $</td>";
                        echo "<td>$description</td>";
                        echo "<td><img src='$image' alt='$name' width='50'></td>";
                        echo "<td>
                                <a href='editproduct.php?id=$id' class='button'>Edit</a> |
                                <a href='delete_product.php?id=$id' class='button'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='12'>No products found</td></tr>";
                }

                // Close connection
                $conn->close();
                ?>
            </table>
        </section>
    </main>

    <footer>
        <p>&COPY;2023 GFG Shopping Web Application</p>
    </footer>
</body>

</html>
                