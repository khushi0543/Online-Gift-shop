<?php

session_start();
// Check if the admin is logged in
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
require 'db.php'; 

if (isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];

    $q = "SELECT * FROM product WHERE productid = '$id'";
    $res = mysqli_query($conn, $q) or die('Query Failed!!!' . mysqli_error($conn));
    $product = mysqli_fetch_array($res);
    
?>
<!DOCTYPE html>
<html>

<head>
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 150vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f4f4f4;
        }

        .container {
            width: 500px;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #000;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
    
  
</head>

<body>
    <div class="container">
        <h1>Edit Product</h1>
        <form method="POST" enctype="multipart/form-data">
            <label>Name:</label><br>
            <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required><br>

            <label>Brand ID:</label><br>
            <input type="number" name="brand" value="<?php echo $product['brand_id']; ?>" required><br>

            <label>Category ID:</label><br>
            <select id="category" name="category_id" required>
                <option value="">Select Category</option>
                <?php
                $sql = "SELECT id, categoryname FROM category";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    $selected = $row['id'] == $product['category_id'] ? 'selected' : '';
                    echo "<option value='" . $row['id'] . "' $selected>" . $row['categoryname'] . "</option>";
                }
                ?>
            </select><br>

            <label>Subcategory ID:</label><br>
            <select id="subcategory" name="subcategory" required>
                <option value="<?php echo $product['subcategory_id']; ?>">Current Subcategory</option>
                <?php
                $sql = "SELECT id, subcategoryname FROM subcategory";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    $selected = $row['id'] == $product['category_id'] ? 'selected' : '';
                    echo "<option value='" . $row['id'] . "' $selected>" . $row['subcategoryname'] . "</option>";
                }
                ?>
            </select><br>

            <label>Color ID:</label><br>
            <input type="number" name="color" value="<?php echo $product['color_id']; ?>" required><br>

            <label>Size ID:</label><br>
            <input type="number" name="size" value="<?php echo $product['size_id']; ?>" required><br>

            <label>Quantity:</label><br>
            <input type="number" name="quantity" value="<?php echo $product['qty']; ?>" required><br>

            <label>Regular Price:</label><br>
            <input type="text" name="regular_price" value="<?php echo $product['regularprice']; ?>" required><br>

            <label>Sale Price:</label><br>
            <input type="text" name="sale_price" value="<?php echo $product['saleprice']; ?>" required><br>

            <label>Description:</label><br>
            <textarea name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea><br>

            <label>Image:</label><br>
            <input type="file" name="image"><br><br>

            <input type="submit" name="update" value="Update Product">
        </form>
    </div>
</body>

</html>



<?php
if (isset($_REQUEST['update'])) {
        $name = $_REQUEST['name'];
        $brand = $_REQUEST['brand'];
        $category = $_REQUEST['category'];
        $subcategory = $_REQUEST['subcategory'];
        $color = $_REQUEST['color'];
        $size = $_REQUEST['size'];
        $quantity = $_REQUEST['quantity'];
        $regular_price = $_REQUEST['regular_price'];
        $sale_price = $_REQUEST['sale_price'];
        $description = $_REQUEST['description'];
        
        //  image upload
        $image = $_FILES['image']['name'];
        if ($image) {
            move_uploaded_file($_FILES['image']['tmp_name'], "uploads/$image");
            $image_sql = ", image = '$image'";
        } else {
            $image_sql = "";
        }

        // Update query
        $q = "UPDATE product SET name = '$name', brand_id = '$brand', category_id = '$category', subcategory_id = '$subcategory', color_id = '$color', size_id = '$size', qty = '$quantity', regularprice = '$regular_price', saleprice = '$sale_price', description = '$description' $image_sql WHERE productid = '$id'";
        if (mysqli_query($conn, $q)) {
            header("Location: manage_product.php?umsg=Product updated successfully!");  
        } else {
            echo "Update Failed: " . mysqli_error($conn);
        }
    }
} else {
    die("No product ID provided!");
}
?>