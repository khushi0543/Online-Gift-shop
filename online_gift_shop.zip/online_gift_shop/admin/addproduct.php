<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin-top: 80px;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 30px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="file"] {
            padding: 10px;
            margin-bottom: 0px;
            border: none;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        select, textarea {
            height: 40px;
        }

        textarea {
            height: 100px;
            resize: none;
        }

        .form-group {
            margin-bottom: 15px;
        }


        @media (max-width: 768px) {
            form {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <h2>Add Product</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" required>
        </div>


        <div class="form-group">
            <label for="brand">Brand:</label>
            <select id="brand" name="brand_id" required>
                <option value="">Select Brand</option>
                <?php
                include 'db.php';
                $sql = "SELECT id, brandname FROM brand";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['brandname'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="category">Category:</label>
            <select id="category" name="category_id" required>
                <option value="">Select Category</option>
                <?php

                $sql = "SELECT id, categoryname FROM category";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['categoryname'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="subcategory">Subcategory:</label>
            <select id="subcategory" name="subcategory_id" required>
                <option value="">Select Subcategory</option>
                <?php
                $sql = "SELECT id, subcategoryname FROM subcategory";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['subcategoryname'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="color">Color:</label>
            <select id="color" name="color_id" required>
                <option value="">Select Color</option>
                <?php
                $sql = "SELECT id, colorname FROM color";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['colorname'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="size">Size:</label>
            <select id="size" name="size_id" required>
                <option value="">Select Size</option>
                <?php
                $sql = "SELECT id, sizename FROM size";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['sizename'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="qty">Quantity:</label>
            <input type="number" id="qty" name="qty" required>
        </div>

        <div class="form-group">
            <label for="regularprice">Regular Price:</label>
            <input type="text" id="regularprice" name="regularprice" required>
        </div>

        <div class="form-group">
            <label for="saleprice">Sale Price:</label>
            <input type="text" id="saleprice" name="saleprice">
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description"></textarea>
        </div>

        <div class="form-group">
            <label for="image">Product Image:</label>
            <input type="file" id="image" name="image">
        </div>

        <input type="submit" value="Add Product" name="insert">
    </form>
</body>
</html>

<?php
include 'db.php';

if (isset($_REQUEST['insert'])) {

    // Get and sanitize form data
    $product_name = $_REQUEST['name'];
    $brand_id = $_REQUEST['brand_id'];
    $category_id = $_REQUEST['category_id'];
    $subcategory_id = $_REQUEST['subcategory_id'];
    $color_id = $_REQUEST['color_id'];
    $size_id = $_REQUEST['size_id'];
    $quantity = $_REQUEST['qty'];
    $regular_price = $_REQUEST['regularprice'];
    $sale_price = $_REQUEST['saleprice'];
    $description = $_REQUEST['description'];
    $errors = array();
    $image_path = null;
    echo "Product Name: $product_name, Sale Price: $sale_price<br>";

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_file_types = array('jpg', 'jpeg', 'png', 'gif');
        $max_file_size = 2 * 1024 * 1024; // 2MB


        if (!in_array($file_ext, $allowed_file_types)) {
            $errors[] = "File type not allowed, please choose a JPEG, PNG, or GIF file.";
        }

        if ($file_size > $max_file_size) {
            $errors[] = "File size must be less than 2MB.";
        }


        if (empty($errors)) {
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true);
            }

            $target_file = $target_dir . basename($file_name);
            if (move_uploaded_file($file_tmp, $target_file)) {
                $image_path = basename($file_name); // Only store the filename
            } else {
                $errors[] = "Error uploading file.";
            }
        }
    } elseif ($_FILES['image']['error'] != 0) {
        $errors[] = "Error with file upload.";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    } 
    else {

        $sql = "INSERT INTO product VALUES (null,'$product_name', $brand_id, $category_id, $subcategory_id, $color_id, $size_id, $quantity, '$regular_price', '$sale_price', '$description', '$image_path')";

        // Execute the SQL query
        if (mysqli_query($conn, $sql)) {
            echo "Product added successfully!";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }

}
?>
