<?php
session_start();
if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}

// Include database connection
require 'db.php'; // Ensure this file has $conn initialized

error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'slidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subscribers</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Global Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        .container {
            max-width: 1100px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            font-size: 28px;
            color: #333;
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .subscriber-table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            margin-bottom: 20px;
        }

        .subscriber-table th, .subscriber-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        .subscriber-table th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: #555;
        }

        .subscriber-table tr:nth-child(even) {
            background-color: #f8f8f8;
        }

        .subscriber-table td {
            color: #333;
        }

        /* Success and Error Messages */
        .message {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }

        .message.success {
            color: #28a745;
        }

        .message.error {
            color: #dc3545;
        }

        /* Button Styles */
        .btn {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            display: inline-block;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .subscriber-table th, .subscriber-table td {
                font-size: 14px;
                padding: 10px;
            }

            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Subscribers</h1>

        <?php
        // Query to select all subscribers from the database
        $result = mysqli_query($conn, "SELECT * FROM subscribers");

        // Check for SQL errors
        if (!$result) {
            echo "<p class='message error'>SQL Error: " . mysqli_error($conn) . "</p>";
        } else {
            // Check if there are subscribers and display them in a table
            if (mysqli_num_rows($result) > 0) {
                echo "<table class='subscriber-table'>";
                echo "<tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Subscribed At</th>
                    </tr>";

                // Fetch each subscriber and display it
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['subscribed_at']}</td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='message error'>No subscribers found.</p>";
            }
        }

        // Display messages if present
        if (isset($_REQUEST['msg'])) {
            $messageClass = strpos($_REQUEST['msg'], 'failed') ? 'error' : 'success';
            echo "<div class='message $messageClass'>" . htmlspecialchars($_REQUEST['msg']) . "</div>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
