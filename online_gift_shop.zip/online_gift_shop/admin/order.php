<?php
session_start();
include "db.php";
include "slidebar.php";

$orderQuery = "
    SELECT o.orderid, o.userid, o.shippingaddress, o.finalprice, o.alternativemobileno, o.status,
           u.name AS user_name, p.name AS product_name, p.regularprice, p.saleprice,
           pay.card_name 
    FROM orders o
    LEFT JOIN users u ON o.userid = u.uid
    LEFT JOIN product p ON o.productid = p.productid
    LEFT JOIN payment pay ON o.payid = pay.id
    ORDER BY o.orderid DESC";

$result = mysqli_query($conn, $orderQuery);
if (!$result) {
    echo "Error executing query: " . mysqli_error($conn);
    exit();
}
if (mysqli_num_rows($result) === 0) {
    echo "<p>No orders found.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Orders</title>
    <link href="../bs/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }
        .content {
            margin-left: 270px; 
            padding: 0px;
            flex: 1;
        }
        header {
            background-color: #ecf0f5;
            color: #000;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        header h1 {
            margin: 0;
        }
        .header-buttons {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }
        .header-buttons.left {
            left: 20px;
        }
        .header-buttons.right {
            right: 20px;
        }
        .header-buttons a {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
        }
        .order-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .order-table th, .order-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            color: black;
        }
        .order-table th {
            background-color: #f8f8f8;
            text-transform: uppercase;
        }
        .button {
            background-color: #000;
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            text-align: center;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #333;
        }
        .button.delete {
            background-color: #d9534f;
        }
        .button.delete:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="content">
        <header>
            <a href="javascript:history.back()" class="header-buttons left"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a>
            <h1>Manage Orders</h1>
            
        </header>
        <table class="order-table">
            <tr>
                <th>Order ID</th>
                <th>User Name</th>
                <th>Product Name</th>
                <th>Shipping Address</th>
                <th>Final Price</th>
                <th>Alternative Mobile No</th>
                <th>Status</th>
                <th>Payment Card</th>
                <th>Actions</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo $row['orderid']; ?></td>
                <td><?php echo $row['user_name']; ?></td>
                <td><?php echo $row['product_name']; ?></td>
                <td><?php echo $row['shippingaddress']; ?></td>
                <td>₹<?php echo $row['finalprice']; ?></td>
                <td><?php echo $row['alternativemobileno']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td><?php echo $row['card_name']; ?></td>
                <td>
                    <a href="vieworder.php?order_id=<?php echo $row['orderid']; ?>" class="button">View</a>
                    <a href="deleteorder.php?orderid=<?php echo $row['orderid']; ?>" class="button delete"><i class="fas fa-trash"></i> Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
