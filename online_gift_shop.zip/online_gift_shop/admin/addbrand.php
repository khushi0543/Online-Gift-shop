<?php
ob_start();
session_start();

if (!isset($_SESSION['a_email'])) {
    header('Location: index.php');
    exit();
}
include 'slidebar.php';
?>
<html lang="en">

<head>
    <title>Add Brand</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            text-transform: uppercase;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            background-color: #000;
            color: #fff;
            border: none;
            font-size: 16px;
            cursor: pointer;
            text-transform: uppercase;
        }

        input[type="submit"]:hover {
            background-color: #333;
        }

        .form-container table {
            width: 100%;
            border-collapse: collapse;
        }
    </style>
</head>

<body>

    <div class="form-container">
        <h2>Add Brand</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="bname">Brand Name</label>
                <input type="text" name="bname" id="bname" placeholder="Enter brand name" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Insert" name="insert">
            </div>
        </form>
    </div>

</body>

<?php
if (isset($_REQUEST['insert'])) {
    $bname = $_REQUEST['bname'];
    require 'db.php';
    $q = "insert into brand values (null, '$bname')";
    if (mysqli_query($conn, $q))
        header("location: brand.php?imsg=Brand Added");
    else
        die("Query Failed!!!" . mysqli_error($conn));
}
?>

</html>
